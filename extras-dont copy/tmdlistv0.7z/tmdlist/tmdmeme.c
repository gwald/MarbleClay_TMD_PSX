
#define YAREXE_VER "YAREXE - v5 June 2023 - bug fixes"
#define YAREXE "Net Yaroze PS-X packager"

#ifndef __TCC__
#include <dirent.h>
#else
/*
 * static char rcsid[] = "$Id: dirent.h,v 1.3 2008/04/06 18:43:58 jullien Exp $";
 */

/*
 * This  program  is  free  software;  you can redistribute it and/or
 * modify  it  under  the  terms of the GNU General Public License as
 * published  by  the  Free  Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This  program  is  distributed in the hope that it will be useful,
 * but  WITHOUT ANY WARRANTY;  without  even the implied  warranty of
 * MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You  should have received a copy of the GNU General Public License
 * along  with  this  program;  if  not,  write  to the Free Software
 * Foundation,  Inc.,  59  Temple  Place  -  Suite  330,  Boston,  MA
 * 02111-1307, USA.
 */

#ifndef	__DIRENT_H
#define	__DIRENT_H

#if	defined( _WIDECHARS )
#if	!defined( _UNICODE )
#define	_UNICODE
#endif
#if	!defined( UNICODE )
#define	UNICODE
#endif
#endif

#if	defined( __cplusplus )
extern "C" {
#endif

/*
 * Definitions for library routines operating on directories.
 */

#if	defined( _WIN32 ) || defined( _WIN64 )
#include	<limits.h>
#include	<windows.h>
#if	!defined( _WINDOWS_SOURCE )
#define	_WINDOWS_SOURCE
#endif
#endif

#if	defined( _OS2 )
#define	INCL_DOSMISC
#define	INCL_DOSFILEMGR
#include	<os2.h>
#if	!defined( INCL_16 )
typedef ULONG UCOUNT;
#else
typedef USHORT UCOUNT;
#endif
static UCOUNT count;
#endif

#if	!defined( _WINDOWS_SOURCE ) && !defined( _OS2 )
#include	<dos.h>
typedef struct _find_t DOSFINDBUF;
#endif

#if	defined( _UNICODE )
typedef wchar_t _char_t;
#define	_pstrcpy	wcscpy
#define	_pstrcat	wcscat
#define	_pstrlen	wcslen
#define	_STR(s)	(L ## s)
#else
typedef char _char_t;
#define	_pstrcpy	strcpy
#define	_pstrcat	strcat
#define	_pstrlen	strlen
#define	_STR(s)	(s)
#endif

#if	!defined( NAME_MAX )
#if	defined( FILENAME_MAX )
#define	NAME_MAX	FILENAME_MAX
#else
#if	defined( _DOS )
#define	NAME_MAX	13
#else
#define	NAME_MAX	255
#endif	/* _DOS		*/
#endif	/* FILENAME_MAX */
#endif	/* NAME_MAX	*/

#define	I_STD	0x0000		/* Normal file - No restrictions */
#define	I_RDO	0x0001		/* Read only file		 */
#define	I_HID	0x0002		/* Hidden file 			 */
#define	I_SYS	0x0004		/* System file			 */
#define	I_LAB	0x0008		/* Volume ID file		 */
#define	I_DIR	0x0010		/* Subdirectory			 */
#define	I_ARC	0x0020 		/* Archive file			 */

#define	FINDATTRIB	I_STD|I_RDO|I_HID|I_DIR

struct dirent {
	unsigned long d_ino; /* inode number of entry */
	unsigned short d_namlen; /* length of d_name	 */
	/*
	 *	POSIX defined field
	 */
	_char_t d_name[NAME_MAX]; /* filename              */
};

#define	d_reclen	d_namlen

#if	defined( _WINDOWS_SOURCE )
#define	FINDHANDLE		HANDLE
#define	FINDDATA		WIN32_FIND_DATA
#define	filename		cFileName
#define	SysCloseDir( hdir )	FindClose( hdir );
#endif

#if	defined( _OS2 )
#define	FINDHANDLE		unsigned int
#if	defined( _OS2V1 )
#define	FINDDATA		FILEFINDBUF
#else
#define	FINDDATA		FILEFINDBUF3
#endif
#define	filename		achName
#define	SysCloseDir( hdir )	DosFindClose( (HDIR)hdir );
#endif

#if	(defined(_DOS)||defined(MSDOS)) && !defined(_WINDOWS_SOURCE) && !defined(_OS2)
#define	FINDHANDLE		unsigned int
#define	FINDDATA		DOSFINDBUF
#define	filename		name
#define	SysCloseDir( hdir )
#endif

typedef struct _dirdesc {
	/*
	 *	DIR public (portable) interface
	 */
	unsigned int status; /* Status flag		  */
	long dd_loc; /* Current location	  */
	_char_t * dd_path; /* Path name		  */
	struct dirent * dd_direct; /* Pointer to direct	  */
	/*
	 *	DIR private system interface
	 */
	FINDHANDLE dd_hfind; /* Handle to find	  */
	FINDDATA dd_resbuf; /* Find data		  */
}DIR;

extern DIR *opendir( const _char_t *file );
extern struct dirent *readdir( DIR *dirp );
extern void rewinddir( DIR *dirp );
extern int closedir( DIR *dirp );
#if	!defined( _POSIX_SOURCE ) && !defined( _POSIX_C_SOURCE )
extern long telldir( DIR *dirp );
extern void seekdir( DIR *dirp, long loc );
#endif

#if	defined( __cplusplus )
}
#endif

#endif

#if	!defined( lint )
static char rcsid[] = "$Id: dirent.c,v 1.4 2008/11/29 08:57:37 jullien Exp $";
#endif

/*
 * This  program  is  free  software;  you can redistribute it and/or
 * modify  it  under  the  terms of the GNU General Public License as
 * published  by  the  Free  Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This  program  is  distributed in the hope that it will be useful,
 * but  WITHOUT ANY WARRANTY;  without  even the implied  warranty of
 * MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You  should have received a copy of the GNU General Public License
 * along  with  this  program;  if  not,  write  to the Free Software
 * Foundation,  Inc.,  59  Temple  Place  -  Suite  330,  Boston,  MA
 * 02111-1307, USA.
 */

/*
 *	NAME
 *		opendir, readdir, telldir, seekdir, rewinddir, closedir
 *		- directory operations.
 *
 *	SYNTAX
 *		#include <dirent.h>
 *
 *		DIR *opendir(filename)
 *		const char *filename;
 *
 *		struct direct *readdir(dirp)
 *		DIR	*dirp;
 *
 *		void rewinddir(dirp)
 *		DIR	*dirp;
 *
 *		int closedir(dirp)
 *		DIR	*dirp;
 *
 *	POSIX EXTENSIONS
 *		long telldir(dirp)
 *		DIR	*dirp;
 *
 *		void seekdir(dirp, loc)
 *		DIR	*dirp;
 *		long	loc;
 *
 *	DESCRIPTION
 *		Read directory entries with POSIX 1003.1 interface.
 *
 *	SEE ALSO
 *		see DIRECTORY(3) for more informations.
 *
 */

#if	defined( _MSC_VER ) && (_MSC_VER >= 1400)
#define	_CRT_SECURE_NO_DEPRECATE	1
#define	_CRT_NONSTDC_NO_DEPRECATE	1
#endif

#if	!defined( __EMACS_H ) || defined( _DIRECTORY )

/* LINTLIBRARY */

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>
#if	!defined( _WIN32_WCE )
#include	<io.h>
#endif	/* _WIN32_WCE */

#if	defined( MSDOS ) && !defined( _DOS )
#define	_DOS
#endif

#if	defined( _DOS )
#include	<dos.h>

#if	defined( _NO_DOS_FIND )
#if	defined( __SC__ )
#pragma pack(1)
#endif

#if	defined( _XALLOC_DEBUG )
#include	<xmem.h>
#endif

struct _find_t {
	unsigned char reserved[21]; /* DOS use (find next)	  */
	unsigned char attrib; /* attribute found	  */
	unsigned short wr_time; /* file's time		  */
	unsigned short wr_date; /* file's last write	  */
	long size; /* size of current file	  */
	char name[13]; /* file name              */
};

#if	defined( __SC__ )
#pragma pack()
#endif

static int _dos_findfirst( _char_t *buf, int attribute, struct _find_t *dp );
static int _dos_findnext( struct _find_t *dp );
static void SYSCALL( unsigned int syscall );
static void install( DIR *dp );
static void restore( void );
#endif

#endif	/* DOS */

DIR *
opendir( const _char_t *dirname )
{
	DIR *dp;

	dp = (DIR *)malloc( sizeof( DIR ) );

	if( dp == (DIR *)NULL )
		return( NULL );

	dp->dd_direct = (struct dirent *)malloc( sizeof( struct dirent ) );
	dp->dd_hfind = (FINDHANDLE)0;

	if( dp->dd_direct == (struct dirent *)NULL ) {
		free( dp );
		return( NULL );
	}

	dp->dd_path = (_char_t *)malloc(sizeof(_char_t)*((size_t)_pstrlen(dirname)+1) );
	(void)_pstrcpy( dp->dd_path, dirname );

	rewinddir( dp );

	if( dp->status ) {
		free( dp->dd_path );
		free( dp->dd_direct );
		free( dp );
		return( NULL );
	}

	return( dp );
}

struct dirent *
readdir( DIR *dp )
{
	struct dirent *dent = dp->dd_direct;

	if( dp->dd_loc != 0 ) {
#if		defined( _OS2 )
		count = 1;
		dp->status = DosFindNext(
				dp->dd_hfind,
				&dp->dd_resbuf,
				(ULONG)sizeof( dp->dd_resbuf ),
				&count
		);
#endif

#if		defined( _WINDOWS_SOURCE )
		dp->status = (FindNextFile(dp->dd_hfind,&dp->dd_resbuf)!=TRUE);
#endif

#if		defined( _DOS )
		dp->status = _dos_findnext( &dp->dd_resbuf );
#endif
	}

	if( dp->status )
		return( (struct dirent *)NULL );

#if	defined( _WINDOWS_SOURCE ) && defined( _OEM_CONVERT )
	(void)CharToOem( dp->dd_resbuf.filename, dent->d_name );
#else
	(void)_pstrcpy(&dent->d_name[0],(_char_t *)&dp->dd_resbuf.filename[0]);
#endif

#if	!defined( _WINDOWS_SOURCE ) || defined( _LOWERCASE )
	(void)strlwr( dent->d_name );
#endif

	dent->d_ino = (unsigned long)dp->dd_loc++;
	dent->d_namlen = (unsigned short)_pstrlen( dent->d_name );

	return( dent );
}

void
rewinddir( DIR *dp )
{
	_char_t buf[ NAME_MAX + 8 ];
	_char_t c;

	(void)_pstrcpy( buf, dp->dd_path );

	if( ((c = buf[(int)_pstrlen(buf)-1]) != '/') && c != '\\' )
		(void)_pstrcat( buf, _STR("\\*.*") );
	else (void)_pstrcat( buf, _STR("*.*") );

	if( dp->dd_hfind )
		SysCloseDir( dp->dd_hfind );

#if	defined( _OS2 )
	count = 1;
	dp->dd_hfind = HDIR_CREATE;
	dp->status = DosFindFirst(
			(_char_t *)&buf[0],
			(PHDIR)&dp->dd_hfind,
			(ULONG)FINDATTRIB,
			&dp->dd_resbuf,
			(ULONG)sizeof( dp->dd_resbuf ),
			(PULONG)&count,
#if	defined( _OS2V1 )
			0L
#else
			(ULONG)FIL_STANDARD
#endif
	);

	if( _osmode == DOS_MODE )
		dp->dd_hfind = HDIR_SYSTEM; /* real mode */
#endif	/* _OS2 */

#if	defined( _WINDOWS_SOURCE )
	dp->dd_hfind = FindFirstFile( &buf[0], &dp->dd_resbuf );
	dp->status = (dp->dd_hfind == INVALID_HANDLE_VALUE);
#endif	/* _WINDOWS_SOURCE */

#if	defined( _DOS )
	dp->dd_hfind = 1;
	dp->status = _dos_findfirst( buf, FINDATTRIB, &dp->dd_resbuf );
#endif	/* _DOS */

	dp->dd_loc = 0;
}

int
closedir( DIR *dp )
{
	if( dp->dd_hfind )
		SysCloseDir( dp->dd_hfind );

	free( dp->dd_path );
	free( dp->dd_direct );
	free( dp );

	return( 0 );
}

#if	!defined( _POSIX_SOURCE ) && !defined( _POSIX_C_SOURCE )

long
telldir( DIR *dirp )
{
	return( dirp->dd_loc );
}

void
seekdir( DIR *dirp, long loc )
{
	rewinddir( dirp );

	while( (dirp->dd_loc < loc-1) && !dirp->status )
		(void)readdir( dirp );
}

#endif

#if	defined( _DOS ) && defined( _NO_DOS_FIND )

/*
 *	Old interface with int86 routines (obsolete).
 */

#define	GETDTA		0x2F00
#define	SETDTA		0x1A00
#define	FINDFIRST	0x4E00
#define	FINDNEXT	0x4F00

#define	AX		sys_regs.x.ax
#define	BX		sys_regs.x.bx
#define	CX		sys_regs.x.cx
#define	DX		sys_regs.x.dx
#define	DS		seg_regs.ds
#define	ES		seg_regs.es

union REGS sys_regs;
static unsigned int odp_off;

#if	defined( M_I86CM ) || defined( M_I86LM ) || defined( M_I86HM ) || defined( __COMPACT__ ) || defined( __MEDIUM__ ) || defined( __LARGE__ )

static unsigned int odp_seg;
struct SREGS seg_regs;
#define	SYSTEM()		int86x( 0x21, &sys_regs, &sys_regs, &seg_regs )
#define	getseg( dta )		((unsigned int)((unsigned long)dta >> 16))
#define	getoffset( dta )	((unsigned int)((unsigned long)dta))
#define	setseg( seg, val )	(seg = val)

#else

#define	SYSTEM()		int86( 0x21, &sys_regs, &sys_regs );
#define	getseg( dta )
#define	getoffset( dta )	((unsigned int)dta)
#define	setseg( seg, val )

#endif

int
_dos_findfirst( buf, attribute, dp )
_char_t *buf;
int attribute;
struct _find_t *dp;
{
	install( dp );
	DX = getoffset( buf );
	DS = getseg( buf );
	CX = attribute;
	SYSCALL( FINDFIRST );
	restore();

	return( AX & 0xFF );
}

int
_dos_findnext( dp )
struct _find_t *dp;
{
	install( dp );
	SYSCALL( FINDNEXT );
	restore();

	return( AX & 0xFF );
}

static void
SYSCALL( syscall )
unsigned int syscall;
{
	AX = syscall;
	SYSTEM();
}

static void
install( dp )
DIR *dp;
{
	SYSCALL( GETDTA );
	odp_off = BX;
	setseg( odp_seg, ES );
	DX = getoffset( dp );
	DS = getseg( dp );
	SYSCALL( SETDTA );
}

static void
restore()
{
	DX = odp_off;
	setseg( DS, odp_seg );
	SYSCALL( SETDTA );
}

#endif
#endif

#if	defined( _TESTDIR )
#include	<stdio.h>
#include	<stdlib.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	"dirent.h"

#if	!defined( S_ISDIR )
#define	S_ISDIR( mode )		(((mode) & S_IFMT) == S_IFDIR)
#endif

#if	!defined( S_ISREG )
#define	S_ISREG( mode )		((mode) & S_IFREG)
#endif

#if	!defined( NFILEN )
#define	NFILEN	256
#endif

void
list( d )
_char_t *d;
{
	DIR *dirp;
	struct dirent *dp;
	_char_t buf[ NFILEN ];
	struct stat stb;

	dirp = opendir( d );

	if( !dirp ) {
		LOG( _STR("No such directory: %s"), d );
		return;
	}

	while( (dp = readdir( dirp )) != NULL ) {
		sLOG( buf, _STR("%s/%s"), d, dp->d_name );
		LOG( _STR("%s\n"), buf );
		if( stat( (_char_t *)buf, &stb ) == 0 &&
				(S_ISREG( stb.st_mode ) || S_ISDIR( stb.st_mode )) ) {
			int isdir = S_ISDIR( stb.st_mode );
			_char_t* cdir = isdir ? _STR("/") : _STR("");

			if( !strcmp(dp->d_name,_STR("."))
					|| !strcmp(dp->d_name,_STR("..")) )
				continue;

			if( isdir )
				list( buf );
		}
	}
}

int
main( argc, argv )
int argc;
_char_t *argv[];
{
	if( argc > 1 )
		list( argv[ 1 ] );
}

#endif

#endif

#include <stdarg.h>

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h> // tolower/upper

typedef unsigned long u_long;

#define sws_setHEADER(h) \
		(h)->id = 0x00000041, \
		(h)->flag = 1, \
		(h)->nobj = 1

#define sws_setOBJECT(o) \
		(o)->vert_top = TMD_VERTEX_LIST_START, \
		(o)->n_vert = TMD_VERTEX_QUANTITY, \
		(o)->normal_top = TMD_NORMAL_LIST_START, \
		(o)->n_normal = TMD_NORMAL_QUANTITY, \
		(o)->primitive_top = TMD_PRIMITIVE_LIST_START, \
		(o)->n_primitive = TMD_PRIMITIVE_QUANTITY, \
		(o)->scale = 0

#define sws_setPRIMITIVE_HEADER(p,m,f,i,o) \
		(p)->mode = (m), \
		(p)->flag = (f), \
		(p)->ilen = (i), \
		(p)->olen = (o)

// **** global structures that define the tmd file format
typedef struct {
	u_long id;
	u_long flag;
	u_long nobj;
} TMDHEADER;

typedef struct {
	u_long vert_top;
	u_long n_vert;
	u_long normal_top;
	u_long n_normal;
	u_long primitive_top;
	u_long n_primitive;
	long scale;
} TMDOBJECT;

typedef struct {		/* short word type 3D vector */
	short	vx, vy;
	short	vz, pad;
} SVECTOR;


int g_verbose = 0;

long file_length(FILE *handle) {
	long retval;
	fseek(handle, 0, SEEK_END);
	retval = ftell(handle);
	fseek(handle, 0, SEEK_SET);
	return retval;
}

void readfile(FILE *handle, void *buffer, long length) {
	long templength, templocation = 0;

	while (length > 0) {
		templength = (length > BUFSIZ) ? BUFSIZ : length;
		fread((char *) buffer + templocation, templength, 1, handle);
		length -= templength;
		templocation += templength;
	}
}

void writefile(FILE *handle, void *buffer, long length) {
	long templength, templocation = 0;
	char test[] = "lit4";

	if (handle == NULL) // not opened
		return; //do nothing

	while (length > 0) {
		templength = 1; //(length > BUFSIZ) ? BUFSIZ : length;

		//LOG("%d\n", strcmp(test, (char *) buffer + templocation ) );

		if (strcmp(test, (char *) buffer + templocation) == 0) {
#if 0
			char sdata[]="sdat";
			long i;

			LOG("lit4 found %d\n",templocation);

			for(i=0;i<length;i++)
			{
				LOG("%d %d %x\n",i, strcmp(sdata, (char *) (buffer +templocation + i ) ), *((char *)(buffer +templocation + i ) ) );

				// if(strcmp(sdata,(char *) buffer + templocation + i ) == 0)
				if( ( (char *)(buffer +templocation + i ) == 73) &&
						( (char *)(buffer +templocation + i +1 ) == 64) &&
						( (char *)(buffer +templocation + i +2 ) == 61) &&
						( (char *)(buffer +templocation + i +3 ) == 74)
				)
				{
					templocation += i;
					break;
				}
			}
#endif

			templocation += 40;
		}

		fwrite((char *) buffer + templocation, templength, 1, handle);

		length -= templength;
		templocation += templength;
	}
}

char *str2lwr(char *str) {
	unsigned char *p = (unsigned char *) str;

	while (*p) {
		*p = tolower((unsigned char) *p);
		p++;
	}

	return str;
}

char *str2upr(char *str) {
	unsigned char *p = (unsigned char *) str;

	while (*p) {
		*p = toupper((unsigned char) *p);
		p++;
	}

	return str;
}

//		sLOG(systemcalldata, "%s -p %s", eco2exe_filename, COMBINE_TMP_FILENAME);
//		system(systemcalldata);

void print_authors(void)

{
	LOG(
			"\n------------------------------------------------------------------------------\n");

	LOG(YAREXE_VER);
	LOG("\n");
	LOG(YAREXE);

	LOG("\nHacked together (poorly) by gwald, from:");
	LOG(
			"\n\nCombine program v2.20\n"
			"By Barubary 1998.\n"

			"\neco2exe v0.5\n"
			"By  Silpheed/HITMEN 1998\n"

			"\nexefixup v0.02\n"
			"By Andrew Kieschnick <andrewk@mail.utexas.edu>\n"

			"\nCodeWarrior PS-X EXE File Patcher\n"
			"By ~imilco (Peter Armstrong)\n"

			"\nCopyright is of the respective owners, wherever they are... we thank you!"
			"\n------------------------------------------------------------------------------\n\n");

	fflush(stdout);
}

void LOG(const char *format, ...) {
	va_list arg;

	if (!g_verbose)
		return;

	va_start(arg, format);
	printf(format, arg);
	fflush(stdout);
	va_end(arg);

	return;
}

void fail(const char *msg, char *file)
{
	printf("Error: %s  File: %s  \n", msg, file);
	fflush(stdout);
	exit(1);
}


char *g_tmd_list[256] = { 0 };
u_long g_tmd_count = 0;
u_long g_normals =1;

int main(int argc, char *argv[]) {
	int index, curline, ret = 1;
	unsigned char temp;


	printf("argc <%d>\n",argc );

	//first check for verbose mode
	if(argc > 1)
	{

		if (strcmp(argv[1], "-n") == 0 || strcmp(argv[1], "-N") == 0)
		{
			g_normals = 0;
			printf("No normals set <%s>\n",argv[1]);
		}

		if (strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "-V") == 0)
			g_verbose = 1;

		if(argc > 2)
		{
			if (strcmp(argv[2], "-v") == 0 || strcmp(argv[2], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[2], "-n") == 0 || strcmp(argv[2], "-N") == 0)
			{
				g_normals = 0;
				printf("No normals set <%s>\n",argv[2]);
			}

		}

	}


	LOG("\n");

	{
		DIR *dir;
		struct dirent *ent;
		if ((dir = opendir(".")) != NULL)
		{
			/* print all the files and directories within directory */
			while ((ent = readdir(dir)) != NULL)
			{

				printf("%s\n", ent->d_name);
				//if( !strcmp(ent->d_name, ".tmd") || !strcmp(ent->d_name, ".TMD")  )
				if( strstr(ent->d_name, ".tmd") || strstr(ent->d_name, ".TMD")  )
				{
					printf("<%s>\n", ent->d_name);
					g_tmd_list[g_tmd_count] = calloc(1, strlen(ent->d_name)+1);
					memcpy(g_tmd_list[g_tmd_count], ent->d_name, strlen(ent->d_name));
					g_tmd_count++;
				}
			}
			closedir(dir);
		} else {
			/* could not open directory */
			fail("failed to open local directory",".");

		}
	}


	if(g_tmd_count > 0)
	{
		u_long ret, i, vert_start, prim_size, total_size, vert_top,n_vertandnorm_size, vert_size, norm_size ;
		char *save_data;
		char *frame_vert, frame_norm;
		FILE *rp, *wp;
		OBJECT obj, obj2;
		HEADER hdr;
		SVECTOR svect;

		printf("\nprocessing...\n");
		i = 0;
		LOG("\n%d = %s\n", i, g_tmd_list[i]);


		rp = fopen( g_tmd_list[i], "rb" );

		if(!rp)
		{

			fail("\n Error failed to open", g_tmd_list[i]);
		}

		fseek(rp, 0L, SEEK_END);
		total_size = ftell(rp);


		LOG(" 1st TMD total_size %d \n", total_size);

		//fseek(rp, 0L, SEEK_SET);
		rewind(rp);

		fread( &hdr, sizeof(HEADER), 1, rp);
		fread( &obj, sizeof(OBJECT), 1, rp);
		// fseek(rp, 0L, SEEK_SET);
		vert_top = sizeof(HEADER)+(u_long)obj.vert_top;



		LOG(" header as read from file!\n\n");

		LOG("header id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);


		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);





		/*
		object primitive_top 0x1c 28
		object n_primitive 0x3ae 942
		object vert_top 0x4794 18324
		object n_vert 0x388 904
		object normal_top 0x63d4 25556
		object n_normal 0x3ae 942
		 */

		vert_start = (u_long)obj.vert_top + sizeof(HEADER);
		vert_size =  ((u_long) obj.normal_top -  (u_long) obj.vert_top) ;
		prim_size = ((u_long)obj.vert_top - (u_long)obj.primitive_top);

		if(g_normals)
		{
			LOG("\nHas g_normals\n");
			n_vertandnorm_size =  (u_long) total_size - (u_long) obj.vert_top ;
			norm_size =  total_size - (u_long) obj.normal_top;
		}
		else //vert only data
		{
			obj.n_normal =(u_long) 0;
			n_vertandnorm_size =  (u_long) vert_size + 0;
			norm_size =(u_long) 0; // Not sure why 32bytes need to be here
			// removing unused normals requires primitive top to be moved up
			//obj.primitive_top = obj.normal_top;
		}

		/*
		if(g_normals)
						fseek(rp,  (u_long)obj.vert_top, SEEK_SET);
					else
						fseek(rp,  vert_start, SEEK_SET);


					ret = fread(save_data,  1 , n_vertandnorm_size, rp);
		 */
		LOG("\n\n header correct ordered with info\n");

		LOG("\nheader id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("\n");
		LOG("3 longs = %d bytes - numbers below start after here and dont include the header!\n\n",sizeof(HEADER) );

		LOG("primative block start location from hdr: %d includes object table(%d) but from zero = %d \n",(u_long)obj.primitive_top, sizeof(OBJECT), (u_long)obj.primitive_top+sizeof(HEADER) );
		LOG("each primative block is %d bytes: primative size=  %d  ending primitive location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ( prim_size/(u_long)obj.n_primitive), prim_size, prim_size+sizeof(OBJECT),   prim_size+ sizeof(OBJECT) + sizeof(HEADER));

		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("\n");
		LOG("vert block start location hdr : %d includes  object table(%d) but from zero = %d \n",(u_long)obj.vert_top, sizeof(OBJECT), (u_long)obj.vert_top+sizeof(HEADER) );
		LOG("each vert_top block is %d bytes: vert size=  %d  ending vert location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ((u_long)prim_size/obj.n_primitive), prim_size, prim_size+sizeof(OBJECT),  prim_size+ sizeof(OBJECT) + sizeof(HEADER));

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("\n");
		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);



		LOG(" n_vertandnorm_size %d \n", n_vertandnorm_size);
		LOG(" n_vert_top  %d  \n", (u_long) obj.vert_top);

		LOG(" total_size %d \n ", total_size);


		LOG(" vert_start %d  \n", vert_start);
		LOG(" vert_size %d  \n", vert_size);
		LOG(" norm_size %d  \n",  norm_size);

		LOG(" g_normals %d  \n",  g_normals);

		unlink("TMD_ANIM.PCK");

		wp = fopen( "TMD_MEME.PCK", "wb+" );


		LOG("\n write # 0 vert_top 0x%0x %d  normal_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top,   (u_long)obj.normal_top, (u_long)obj.normal_top );

		LOG(" sizeof(u_long) %d \n\n", sizeof(u_long));

		// count starts from zero
		g_tmd_count--;

		fwrite(&g_tmd_count, sizeof(u_long), 1, wp );

		fwrite(&vert_start, sizeof(u_long), 1, wp );



		//	fwrite(&n_vertandnorm_size, sizeof(u_long), 1, wp );
		fwrite(&vert_size, sizeof(u_long), 1, wp );
		fwrite(&norm_size, sizeof(u_long), 1, wp );

		// restore start from 1
		g_tmd_count++;



		ret = fread( frame_vert, 1, vert_size, rp);

		LOG("1st TMD read:%d size:%d \n", ret, vert_size);
		if(ret != vert_size)
		{

			LOG("\n Error failed to read 1st TMD vert_size %s\n", g_tmd_list[0]);
			LOG("\n");
			perror("File reading vert_size failed");
			fflush(stdout);
			exit(1);
		}

		ret = fread( frame_norm, 1, norm_size, rp);

		LOG("1st TMD read:%d size:%d \n", ret, norm_size);
		if(ret != norm_size)
		{

			LOG("\n Error failed to read 1st TMD norm_size %s\n", g_tmd_list[0]);
			LOG("\n");
			perror("File reading vert_size failed");
			fflush(stdout);
			exit(1);
		}

		if(g_normals) // save complete 1st TMD
		{

			rewind(rp);


			save_data = malloc(total_size);

			if(!save_data)
			{

				LOG("\n Error failed to read 1st TMD %s - No RAM!\n", g_tmd_list[0]);
				LOG("\n");
				perror("NO RAM!");
				fflush(stdout);
				exit(1);
			}


			ret = fread( save_data, 1, total_size, rp);

			LOG("1st TMD read:%d size:%d \n", ret, total_size);
			if(ret != total_size)
			{

				LOG("\n Error failed to read 1st TMD %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}


			//write 1st TMD
			ret = fwrite(save_data, 1,total_size, wp );

			LOG("save_data write:%d size:%d \n", ret, total_size);
			if(ret != total_size)
			{
				LOG("\n Error failed to read 1st TMD %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}

		}
		else // strip normal data from TMD
		{


			ret = fwrite(&hdr, 1, sizeof(HEADER), wp );

			LOG("hdr write:%d size:%d \n", ret, sizeof(HEADER));
			if(ret != sizeof(HEADER))
			{
				LOG("\n Error failed to write 1st TMD HDR %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File write failed");
				fflush(stdout);
				exit(1);
			}



			ret = fwrite(&obj, 1, sizeof(OBJECT), wp );

			LOG("obj write:%d size:%d \n", ret, sizeof(OBJECT));
			if(ret != sizeof(OBJECT))
			{
				LOG("\n Error failed to write 1st TMD obj %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File write failed");
				fflush(stdout);
				exit(1);
			}


			// write prim face data



			/*
			object primitive_top 0x1c 28
			object n_primitive 0x3ae 942
			object vert_top 0x4794 18324
			object n_vert 0x388 904
			object normal_top 0x63d4 25556
			object n_normal 0x3ae 942
			 */

			//skip past hrd and obj data
			fseek(rp, sizeof(HEADER) + sizeof(OBJECT), SEEK_SET);




			LOG(" obj.normal_top- obj.vert_top %d \n", (u_long)obj.normal_top );
			LOG("  sizeof(HEADER) + sizeof(OBJECT) %d \n",  sizeof(HEADER) + sizeof(OBJECT));


			// read and store data from prim top to normal top, the primitive faces and vert data
			save_data = malloc( (u_long)obj.normal_top - sizeof(OBJECT) );
			ret = fread( save_data, 1, (u_long)obj.normal_top - sizeof(OBJECT), rp);

			LOG("1st TMD read primitive faces and vert data:%d size:%d \n", ret,  (u_long)obj.normal_top  - sizeof(OBJECT));
			if(ret !=  (u_long)obj.normal_top  - sizeof(OBJECT))
			{

				LOG("\n Error failed to read 1st TMD primitive faces and vert data %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}



			ret = fwrite(save_data, 1,   (u_long)obj.normal_top  - sizeof(OBJECT), wp );

			LOG("obj write:%d size:%d \n", ret,  (u_long)obj.normal_top  - sizeof(OBJECT));
			if(ret != (u_long)obj.normal_top   - sizeof(OBJECT))
			{
				LOG("\n Error failed to write 1st TMD primitive faces and vert data %s\n", g_tmd_list[0]);
				LOG("\n");
				perror("File write failed");
				fflush(stdout);
				exit(1);
			}



			//empty normals are 32bytes, they have to be, i dont know why

			// fwrite(&norm_size, sizeof(u_long), 1, wp );


		}

		free(save_data);
		fclose(rp);

		// fflush(wp);





		// write vert & norm of remaining TMDs
		save_data = malloc(n_vertandnorm_size);


		LOG("\nwriting meme data...\n");
		for (i = 1; i < g_tmd_count; i++)
		{
			LOG("\n file %d = %s\n", i, g_tmd_list[i]);

			rp = fopen( g_tmd_list[i], "rb" );

			if(rp == NULL)
			{
				LOG("\n Error failed to open %s\n", g_tmd_list[i]);
				LOG("\n");
				perror("File opening failed");
				fflush(stdout);
				exit(1);
			}

			rewind(rp);

			fread( &obj2, 1, sizeof(HEADER), rp); //move FP
			ret = fread( &obj2, 1, sizeof(OBJECT), rp);

			if(ret != sizeof(OBJECT) || obj.n_vert != obj2.n_vert)
			{
				LOG("\n Error failed to read 1st %s TMD doesn't have the same amount of verts as the first TMD %s\n", g_tmd_list[i], g_tmd_list[0]);
				LOG("\n");
				perror("TMD error");
				fflush(stdout);
				exit(1);
			}


			rewind(rp);

			if(g_normals)
				fseek(rp,  (u_long)obj.vert_top, SEEK_SET);
			else
				fseek(rp,  vert_start, SEEK_SET);



			ret = fread(save_data,  1 , n_vertandnorm_size, rp);
			fflush(rp);
			fclose(rp);
			LOG("save_data read:%d size:%d \n", ret, n_vertandnorm_size);

			if(ret != n_vertandnorm_size)
			{
				LOG("\n Error failed to read %d TMD %s\n",i, g_tmd_list[i]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}


			ret = fwrite(save_data ,  1 , n_vertandnorm_size, wp);


			if(0)
			{
				FILE *test;
				char name[255];
				sLOG(name, "t%s",g_tmd_list[i] );

				test = fopen( name, "wb+" );
				ret = fwrite(save_data ,  1 , n_vertandnorm_size, test);
				fclose(test);

			}

			LOG("save_data write:%d size:%d \n", ret, n_vertandnorm_size);
			if(ret != n_vertandnorm_size)
			{
				LOG("\n Error failed to write %d TMD %s\n",i, g_tmd_list[i]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}
			/// fwrite(&i ,  sizeof( i) , 1 , wp);

			//	fwrite(&norm_size, sizeof(u_long), 1, wp );
		}

		/*
		obj.n_normal= 0;
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		 */

		fclose(wp);

		free(save_data);

		for (i = 0; i < g_tmd_count; i++)
			free(g_tmd_list[i]);


	}
	else
	{
		printf("\n ERROR - no .TMD files found! \n");
	}


	return 0;

}
