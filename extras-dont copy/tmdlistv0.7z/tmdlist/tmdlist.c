#ifndef __TCC__

#include <stdint.h>
typedef uint16_t u_short;
typedef uint32_t u_long;
typedef uint8_t u_char;
#include <dirent.h>

#else

typedef unsigned char u_char;
typedef unsigned long u_long;
typedef unsigned short u_short;
/*
 * static char rcsid[] = "$Id: dirent.h,v 1.3 2008/04/06 18:43:58 jullien Exp $";
 */

/*
 * This  program  is  free  software;  you can redistribute it and/or
 * modify  it  under  the  terms of the GNU General Public License as
 * published  by  the  Free  Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This  program  is  distributed in the hope that it will be useful,
 * but  WITHOUT ANY WARRANTY;  without  even the implied  warranty of
 * MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You  should have received a copy of the GNU General Public License
 * along  with  this  program;  if  not,  write  to the Free Software
 * Foundation,  Inc.,  59  Temple  Place  -  Suite  330,  Boston,  MA
 * 02111-1307, USA.
 */

#ifndef	__DIRENT_H
#define	__DIRENT_H

#if	defined( _WIDECHARS )
#if	!defined( _UNICODE )
#define	_UNICODE
#endif
#if	!defined( UNICODE )
#define	UNICODE
#endif
#endif

#if	defined( __cplusplus )
extern "C" {
#endif

/*
 * Definitions for library routines operating on directories.
 */

#if	defined( _WIN32 ) || defined( _WIN64 )
#include	<limits.h>
#include	<windows.h>
#if	!defined( _WINDOWS_SOURCE )
#define	_WINDOWS_SOURCE
#endif
#endif

#if	defined( _OS2 )
#define	INCL_DOSMISC
#define	INCL_DOSFILEMGR
#include	<os2.h>
#if	!defined( INCL_16 )
typedef ULONG UCOUNT;
#else
typedef USHORT UCOUNT;
#endif
static UCOUNT count;
#endif

#if	!defined( _WINDOWS_SOURCE ) && !defined( _OS2 )
#include	<dos.h>
typedef struct _find_t DOSFINDBUF;
#endif

#if	defined( _UNICODE )
typedef wchar_t _char_t;
#define	_pstrcpy	wcscpy
#define	_pstrcat	wcscat
#define	_pstrlen	wcslen
#define	_STR(s)	(L ## s)
#else
typedef char _char_t;
#define	_pstrcpy	strcpy
#define	_pstrcat	strcat
#define	_pstrlen	strlen
#define	_STR(s)	(s)
#endif

#if	!defined( NAME_MAX )
#if	defined( FILENAME_MAX )
#define	NAME_MAX	FILENAME_MAX
#else
#if	defined( _DOS )
#define	NAME_MAX	13
#else
#define	NAME_MAX	255
#endif	/* _DOS		*/
#endif	/* FILENAME_MAX */
#endif	/* NAME_MAX	*/

#define	I_STD	0x0000		/* Normal file - No restrictions */
#define	I_RDO	0x0001		/* Read only file		 */
#define	I_HID	0x0002		/* Hidden file 			 */
#define	I_SYS	0x0004		/* System file			 */
#define	I_LAB	0x0008		/* Volume ID file		 */
#define	I_DIR	0x0010		/* Subdirectory			 */
#define	I_ARC	0x0020 		/* Archive file			 */

#define	FINDATTRIB	I_STD|I_RDO|I_HID|I_DIR

struct dirent {
	unsigned long d_ino; /* inode number of entry */
	unsigned short d_namlen; /* length of d_name	 */
	/*
	 *	POSIX defined field
	 */
	_char_t d_name[NAME_MAX]; /* filename              */
};

#define	d_reclen	d_namlen

#if	defined( _WINDOWS_SOURCE )
#define	FINDHANDLE		HANDLE
#define	FINDDATA		WIN32_FIND_DATA
#define	filename		cFileName
#define	SysCloseDir( hdir )	FindClose( hdir );
#endif

#if	defined( _OS2 )
#define	FINDHANDLE		unsigned int
#if	defined( _OS2V1 )
#define	FINDDATA		FILEFINDBUF
#else
#define	FINDDATA		FILEFINDBUF3
#endif
#define	filename		achName
#define	SysCloseDir( hdir )	DosFindClose( (HDIR)hdir );
#endif

#if	(defined(_DOS)||defined(MSDOS)) && !defined(_WINDOWS_SOURCE) && !defined(_OS2)
#define	FINDHANDLE		unsigned int
#define	FINDDATA		DOSFINDBUF
#define	filename		name
#define	SysCloseDir( hdir )
#endif

typedef struct _dirdesc {
	/*
	 *	DIR public (portable) interface
	 */
	unsigned int status; /* Status flag		  */
	long dd_loc; /* Current location	  */
	_char_t * dd_path; /* Path name		  */
	struct dirent * dd_direct; /* Pointer to direct	  */
	/*
	 *	DIR private system interface
	 */
	FINDHANDLE dd_hfind; /* Handle to find	  */
	FINDDATA dd_resbuf; /* Find data		  */
}DIR;

extern DIR *opendir( const _char_t *file );
extern struct dirent *readdir( DIR *dirp );
extern void rewinddir( DIR *dirp );
extern int closedir( DIR *dirp );
#if	!defined( _POSIX_SOURCE ) && !defined( _POSIX_C_SOURCE )
extern long telldir( DIR *dirp );
extern void seekdir( DIR *dirp, long loc );
#endif

#if	defined( __cplusplus )
}
#endif

#endif

#if	!defined( lint )
static char rcsid[] = "$Id: dirent.c,v 1.4 2008/11/29 08:57:37 jullien Exp $";
#endif

/*
 * This  program  is  free  software;  you can redistribute it and/or
 * modify  it  under  the  terms of the GNU General Public License as
 * published  by  the  Free  Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This  program  is  distributed in the hope that it will be useful,
 * but  WITHOUT ANY WARRANTY;  without  even the implied  warranty of
 * MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You  should have received a copy of the GNU General Public License
 * along  with  this  program;  if  not,  write  to the Free Software
 * Foundation,  Inc.,  59  Temple  Place  -  Suite  330,  Boston,  MA
 * 02111-1307, USA.
 */

/*
 *	NAME
 *		opendir, readdir, telldir, seekdir, rewinddir, closedir
 *		- directory operations.
 *
 *	SYNTAX
 *		#include <dirent.h>
 *
 *		DIR *opendir(filename)
 *		const char *filename;
 *
 *		struct direct *readdir(dirp)
 *		DIR	*dirp;
 *
 *		void rewinddir(dirp)
 *		DIR	*dirp;
 *
 *		int closedir(dirp)
 *		DIR	*dirp;
 *
 *	POSIX EXTENSIONS
 *		long telldir(dirp)
 *		DIR	*dirp;
 *
 *		void seekdir(dirp, loc)
 *		DIR	*dirp;
 *		long	loc;
 *
 *	DESCRIPTION
 *		Read directory entries with POSIX 1003.1 interface.
 *
 *	SEE ALSO
 *		see DIRECTORY(3) for more informations.
 *
 */

#if	defined( _MSC_VER ) && (_MSC_VER >= 1400)
#define	_CRT_SECURE_NO_DEPRECATE	1
#define	_CRT_NONSTDC_NO_DEPRECATE	1
#endif

#if	!defined( __EMACS_H ) || defined( _DIRECTORY )

/* LINTLIBRARY */

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>
#if	!defined( _WIN32_WCE )
#include	<io.h>
#endif	/* _WIN32_WCE */

#if	defined( MSDOS ) && !defined( _DOS )
#define	_DOS
#endif

#if	defined( _DOS )
#include	<dos.h>

#if	defined( _NO_DOS_FIND )
#if	defined( __SC__ )
#pragma pack(1)
#endif

#if	defined( _XALLOC_DEBUG )
#include	<xmem.h>
#endif

struct _find_t {
	unsigned char reserved[21]; /* DOS use (find next)	  */
	unsigned char attrib; /* attribute found	  */
	unsigned short wr_time; /* file's time		  */
	unsigned short wr_date; /* file's last write	  */
	long size; /* size of current file	  */
	char name[13]; /* file name              */
};

#if	defined( __SC__ )
#pragma pack()
#endif

static int _dos_findfirst( _char_t *buf, int attribute, struct _find_t *dp );
static int _dos_findnext( struct _find_t *dp );
static void SYSCALL( unsigned int syscall );
static void install( DIR *dp );
static void restore( void );
#endif

#endif	/* DOS */

DIR *
opendir( const _char_t *dirname )
{
	DIR *dp;

	dp = (DIR *)malloc( sizeof( DIR ) );

	if( dp == (DIR *)NULL )
		return( NULL );

	dp->dd_direct = (struct dirent *)malloc( sizeof( struct dirent ) );
	dp->dd_hfind = (FINDHANDLE)0;

	if( dp->dd_direct == (struct dirent *)NULL ) {
		free( dp );
		return( NULL );
	}

	dp->dd_path = (_char_t *)malloc(sizeof(_char_t)*((size_t)_pstrlen(dirname)+1) );
	(void)_pstrcpy( dp->dd_path, dirname );

	rewinddir( dp );

	if( dp->status ) {
		free( dp->dd_path );
		free( dp->dd_direct );
		free( dp );
		return( NULL );
	}

	return( dp );
}

struct dirent *
readdir( DIR *dp )
{
	struct dirent *dent = dp->dd_direct;

	if( dp->dd_loc != 0 ) {
#if		defined( _OS2 )
		count = 1;
		dp->status = DosFindNext(
				dp->dd_hfind,
				&dp->dd_resbuf,
				(ULONG)sizeof( dp->dd_resbuf ),
				&count
		);
#endif

#if		defined( _WINDOWS_SOURCE )
		dp->status = (FindNextFile(dp->dd_hfind,&dp->dd_resbuf)!=TRUE);
#endif

#if		defined( _DOS )
		dp->status = _dos_findnext( &dp->dd_resbuf );
#endif
	}

	if( dp->status )
		return( (struct dirent *)NULL );

#if	defined( _WINDOWS_SOURCE ) && defined( _OEM_CONVERT )
	(void)CharToOem( dp->dd_resbuf.filename, dent->d_name );
#else
	(void)_pstrcpy(&dent->d_name[0],(_char_t *)&dp->dd_resbuf.filename[0]);
#endif

#if	!defined( _WINDOWS_SOURCE ) || defined( _LOWERCASE )
	(void)strlwr( dent->d_name );
#endif

	dent->d_ino = (unsigned long)dp->dd_loc++;
	dent->d_namlen = (unsigned short)_pstrlen( dent->d_name );

	return( dent );
}

void
rewinddir( DIR *dp )
{
	_char_t buf[ NAME_MAX + 8 ];
	_char_t c;

	(void)_pstrcpy( buf, dp->dd_path );

	if( ((c = buf[(int)_pstrlen(buf)-1]) != '/') && c != '\\' )
		(void)_pstrcat( buf, _STR("\\*.*") );
	else (void)_pstrcat( buf, _STR("*.*") );

	if( dp->dd_hfind )
		SysCloseDir( dp->dd_hfind );

#if	defined( _OS2 )
	count = 1;
	dp->dd_hfind = HDIR_CREATE;
	dp->status = DosFindFirst(
			(_char_t *)&buf[0],
			(PHDIR)&dp->dd_hfind,
			(ULONG)FINDATTRIB,
			&dp->dd_resbuf,
			(ULONG)sizeof( dp->dd_resbuf ),
			(PULONG)&count,
#if	defined( _OS2V1 )
			0L
#else
			(ULONG)FIL_STANDARD
#endif
	);

	if( _osmode == DOS_MODE )
		dp->dd_hfind = HDIR_SYSTEM; /* real mode */
#endif	/* _OS2 */

#if	defined( _WINDOWS_SOURCE )
	dp->dd_hfind = FindFirstFile( &buf[0], &dp->dd_resbuf );
	dp->status = (dp->dd_hfind == INVALID_HANDLE_VALUE);
#endif	/* _WINDOWS_SOURCE */

#if	defined( _DOS )
	dp->dd_hfind = 1;
	dp->status = _dos_findfirst( buf, FINDATTRIB, &dp->dd_resbuf );
#endif	/* _DOS */

	dp->dd_loc = 0;
}

int
closedir( DIR *dp )
{
	if( dp->dd_hfind )
		SysCloseDir( dp->dd_hfind );

	free( dp->dd_path );
	free( dp->dd_direct );
	free( dp );

	return( 0 );
}

#if	!defined( _POSIX_SOURCE ) && !defined( _POSIX_C_SOURCE )

long
telldir( DIR *dirp )
{
	return( dirp->dd_loc );
}

void
seekdir( DIR *dirp, long loc )
{
	rewinddir( dirp );

	while( (dirp->dd_loc < loc-1) && !dirp->status )
		(void)readdir( dirp );
}

#endif

#if	defined( _DOS ) && defined( _NO_DOS_FIND )

/*
 *	Old interface with int86 routines (obsolete).
 */

#define	GETDTA		0x2F00
#define	SETDTA		0x1A00
#define	FINDFIRST	0x4E00
#define	FINDNEXT	0x4F00

#define	AX		sys_regs.x.ax
#define	BX		sys_regs.x.bx
#define	CX		sys_regs.x.cx
#define	DX		sys_regs.x.dx
#define	DS		seg_regs.ds
#define	ES		seg_regs.es

union REGS sys_regs;
static unsigned int odp_off;

#if	defined( M_I86CM ) || defined( M_I86LM ) || defined( M_I86HM ) || defined( __COMPACT__ ) || defined( __MEDIUM__ ) || defined( __LARGE__ )

static unsigned int odp_seg;
struct SREGS seg_regs;
#define	SYSTEM()		int86x( 0x21, &sys_regs, &sys_regs, &seg_regs )
#define	getseg( dta )		((unsigned int)((unsigned long)dta >> 16))
#define	getoffset( dta )	((unsigned int)((unsigned long)dta))
#define	setseg( seg, val )	(seg = val)

#else

#define	SYSTEM()		int86( 0x21, &sys_regs, &sys_regs );
#define	getseg( dta )
#define	getoffset( dta )	((unsigned int)dta)
#define	setseg( seg, val )

#endif

int
_dos_findfirst( buf, attribute, dp )
_char_t *buf;
int attribute;
struct _find_t *dp;
{
	install( dp );
	DX = getoffset( buf );
	DS = getseg( buf );
	CX = attribute;
	SYSCALL( FINDFIRST );
	restore();

	return( AX & 0xFF );
}

int
_dos_findnext( dp )
struct _find_t *dp;
{
	install( dp );
	SYSCALL( FINDNEXT );
	restore();

	return( AX & 0xFF );
}

static void
SYSCALL( syscall )
unsigned int syscall;
{
	AX = syscall;
	SYSTEM();
}

static void
install( dp )
DIR *dp;
{
	SYSCALL( GETDTA );
	odp_off = BX;
	setseg( odp_seg, ES );
	DX = getoffset( dp );
	DS = getseg( dp );
	SYSCALL( SETDTA );
}

static void
restore()
{
	DX = odp_off;
	setseg( DS, odp_seg );
	SYSCALL( SETDTA );
}

#endif
#endif

#if	defined( _TESTDIR )
#include	<stdio.h>
#include	<stdlib.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	"dirent.h"

#if	!defined( S_ISDIR )
#define	S_ISDIR( mode )		(((mode) & S_IFMT) == S_IFDIR)
#endif

#if	!defined( S_ISREG )
#define	S_ISREG( mode )		((mode) & S_IFREG)
#endif

#if	!defined( NFILEN )
#define	NFILEN	256
#endif

void
list( d )
_char_t *d;
{
	DIR *dirp;
	struct dirent *dp;
	_char_t buf[ NFILEN ];
	struct stat stb;

	dirp = opendir( d );

	if( !dirp ) {
		LOG( _STR("No such directory: %s"), d );
		return;
	}

	while( (dp = readdir( dirp )) != NULL ) {
		sLOG( buf, _STR("%s/%s"), d, dp->d_name );
		LOG( _STR("%s\n"), buf );
		if( stat( (_char_t *)buf, &stb ) == 0 &&
				(S_ISREG( stb.st_mode ) || S_ISDIR( stb.st_mode )) ) {
			int isdir = S_ISDIR( stb.st_mode );
			_char_t* cdir = isdir ? _STR("/") : _STR("");

			if( !strcmp(dp->d_name,_STR("."))
					|| !strcmp(dp->d_name,_STR("..")) )
				continue;

			if( isdir )
				list( buf );
		}
	}
}

int
main( argc, argv )
int argc;
_char_t *argv[];
{
	if( argc > 1 )
		list( argv[ 1 ] );
}

#endif

#endif

#include <stdarg.h>

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h> // tolower/upper

#define sws_setTMDHEADER(h) \
		(h)->id = 0x00000041, \
		(h)->flag = 1, \
		(h)->nobj = 1

#define sws_setTMDOBJECT(o) \
		(o)->vert_top = TMD_VERTEX_LIST_START, \
		(o)->n_vert = TMD_VERTEX_QUANTITY, \
		(o)->normal_top = TMD_NORMAL_LIST_START, \
		(o)->n_normal = TMD_NORMAL_QUANTITY, \
		(o)->primitive_top = TMD_PRIMITIVE_LIST_START, \
		(o)->n_primitive = TMD_PRIMITIVE_QUANTITY, \
		(o)->scale = 0

#define sws_setPRIMITIVE_TMDHEADER(p,m,f,i,o) \
		(p)->mode = (m), \
		(p)->flag = (f), \
		(p)->ilen = (i), \
		(p)->olen = (o)

// **** global structures that define the tmd file format
typedef struct {
	u_long id;
	u_long flag;
	u_long nobj;
} TMDHEADER;

typedef struct {
	u_long vert_top;
	u_long n_vert;
	u_long normal_top;
	u_long n_normal;
	u_long primitive_top;
	u_long n_primitive;
	long scale;
} TMDOBJECT;

typedef struct {		/* short word type 3D vector */
	short	vx, vy;
	short	vz, pad;
} SVECTOR;


typedef struct {
	TMDHEADER hdr;
	TMDOBJECT obj;
} TMD_OBJ_HDR;



typedef struct {
	u_long frames;
	u_long total_size;
	u_long vert_size;
	u_long norm_size;
	u_long *vert_p;
	u_long *normal_p;
	u_long *start_p;
	TMD_OBJ_HDR *TMD_p; ///???
} TMDANIMLISTHDR;

TMDANIMLISTHDR  HDR;
void (*LOG)(const char *format, ...);

void DUMMY(const char *format, ...)
{

	return;
}

void fail(const char *msg, char *file)
{

	unlink("TMD_ANIM.PCK");
	printf("Error: %s  File: %s  \n", msg, file);
	fflush(stdout);
	exit(1);
}


char *g_tmd_list[256] = { 0 };
u_long g_tweens =0;
u_long g_tmd_count = 0;
u_long g_normals =1;
u_long g_verbose = 0;

u_long g_fileframes = 0;
u_long g_include_loopback =0;
u_long g_total_frames_calc =0;

int main(int argc, char *argv[]) {
	int index, curline, ret = 1;
	unsigned char temp;

	g_tmd_count = 0;
	printf("argc <%d>\n",argc );


	//first check for verbose mode
	if(argc > 1)
	{

		printf("\n argv[1] <%s>\n",argv[1]);

		if (strcmp(argv[1], "-n") == 0 || strcmp(argv[1], "-N") == 0)
		{
			g_normals = 0;
			printf("1 No normals set <%s>\n",argv[1]);
		}

		if (strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "-V") == 0)
			g_verbose = 1;




		if (strstr(argv[1], "-l") > 0  || strstr(argv[1], "-L") > 0 )
		{

			g_include_loopback =1;
			printf("\n 1 g_include_loopback -k <%d>\n",g_include_loopback);
		}


		if (strstr(argv[1], "-t") > 0  || strstr(argv[1], "-T") > 0 )
		{

			g_tweens = atoi(&argv[1][2]);
			printf("\n 1 g_tweens -t <%d>\n",g_tweens);
		}


		if(argc > 2)
		{


			printf("\n 2 argv[2] <%s>\n",argv[2]);

			if (strcmp(argv[2], "-v") == 0 || strcmp(argv[2], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[2], "-n") == 0 || strcmp(argv[2], "-N") == 0)
			{
				g_normals = 0;
				printf("2 No normals set <%s>\n",argv[2]);
			}


			if (strstr(argv[2], "-l") > 0  || strstr(argv[2], "-L") > 0 )
			{

				g_include_loopback =1;
				printf("\n 2 g_include_loopback -k <%d>\n",g_include_loopback);
			}

			if (strstr(argv[2], "-t") > 0  || strstr(argv[2], "-T") > 0 )
			{

				g_tweens = atoi(&argv[2][2]);
				printf("\n 2 g_tweens -t <%d>\n",g_tweens);
			}


		}


		if(argc > 3)
		{


			printf("\n 3 argv[3] <%s>\n",argv[3]);

			if (strcmp(argv[3], "-v") == 0 || strcmp(argv[3], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[3], "-n") == 0 || strcmp(argv[3], "-N") == 0)
			{
				g_normals = 0;
				printf("3 No normals set <%s>\n",argv[3]);
			}


			if (strstr(argv[3], "-l") > 0  || strstr(argv[3], "-L") > 0 )
			{

				g_include_loopback =1;
				printf("\n 3 g_include_loopback -k <%d>\n",g_include_loopback);
			}


			if (strstr(argv[3], "-t") > 0  || strstr(argv[3], "-T") > 0 )
			{

				g_tweens = atoi(&argv[3][2]);
				printf("\n 3 g_tweens -t <%d>\n",g_tweens);
			}




		}




		if(argc > 4)
		{


			printf("\n 4 argv[4] <%s>\n",argv[4]);

			if (strcmp(argv[4], "-v") == 0 || strcmp(argv[4], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[4], "-n") == 0 || strcmp(argv[4], "-N") == 0)
			{
				g_normals = 0;
				printf("4 No normals set <%s>\n",argv[4]);
			}


			if (strstr(argv[4], "-l") > 0  || strstr(argv[4], "-L") > 0 )
			{

				g_include_loopback =1;
				printf("\n4 g_include_loopback -k <%d>\n",g_include_loopback);
			}


			if (strstr(argv[4], "-t") > 0  || strstr(argv[4], "-T") > 0 )
			{

				g_tweens = atoi(&argv[4][2]);
				printf("\n4 g_tweens -t <%d>\n",g_tweens);
			}




		}


	}

	if(g_tweens == 1)
		g_tweens=0;

	if(g_verbose)
		LOG = printf;
	else
		LOG = DUMMY;

	LOG("\n");

	{
		DIR *dir;
		struct dirent *ent;
		if ((dir = opendir(".")) != NULL)
		{
			/* print all the files and directories within directory */
			while ((ent = readdir(dir)) != NULL)
			{

				printf("%d %s\n", g_tmd_count, ent->d_name);
				//if( !strcmp(ent->d_name, ".tmd") || !strcmp(ent->d_name, ".TMD")  )
				if( strstr(ent->d_name, ".tmd") || strstr(ent->d_name, ".TMD")  )
				{
					printf("<%s>\n", ent->d_name);
					g_tmd_list[g_tmd_count] = calloc(1, strlen(ent->d_name)+1);
					memcpy(g_tmd_list[g_tmd_count], ent->d_name, strlen(ent->d_name));
					g_tmd_count++;
				}
			}
			closedir(dir);
		} else {
			/* could not open directory */
			fail("failed to open local directory",".");

		}
	}


	if(g_tmd_count > 0)
	{
		u_long ret, i, vert_start, prim_size, total_size, vert_top,n_vertandnorm_size, vert_size, norm_size ;
		char *save_data1;
		char *save_data2;
		char *tween_data;
		char *firstframe_data;

		char *curr_frame;
		char *curr_tween_to;

		FILE *rp, *wp;
		TMDOBJECT obj, obj2;
		TMDHEADER hdr;
		SVECTOR * svect_p;
		SVECTOR svect;

		i = 0;

		printf("\nprocessing... g_tmd_count %d\n",g_tmd_count);

		printf("\n%d = <%s>\n", i, g_tmd_list[i]);


		rp = fopen( g_tmd_list[i], "rb" );

		if(!rp)
		{

			fail("\n Error failed to open", g_tmd_list[i]);
		}

		fseek(rp, 0L, SEEK_END);
		total_size = ftell(rp);


		LOG(" 1st TMD total_size %d \n", total_size);

		//fseek(rp, 0L, SEEK_SET);
		rewind(rp);

		fread( &hdr, sizeof(TMDHEADER), 1, rp);
		fread( &obj, sizeof(TMDOBJECT), 1, rp);
		// fseek(rp, 0L, SEEK_SET);
		vert_top = sizeof(TMDHEADER)+(u_long)obj.vert_top;



		LOG(" header as read from file!\n\n");

		LOG("header id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);


		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);





		/*

header as read from file!
header id 0x41 65
header flag 0x0 0
header noobj 0x1 1
object vert_top 0x4794 18324
object n_vert 0x388 904
object normal_top 0x63d4 25556
object n_normal 0x3ae 942
object primitive_top 0x1c 28
object n_primitive 0x3ae 942
object scale 0x0 0


actual file struct:
primitive_top 0x1c 28
(primative block start location from hdr: 28 includes only the object table(28) but from zero it's 40, OBJ & HDR (28+12=40) , same for the other top addr/sizes)
vert_top 0x4794 18324
normal_top 0x63d4 25556

		 */

		vert_start = (u_long)obj.vert_top + (u_long)sizeof(TMDHEADER);
		vert_size =  ((u_long) obj.normal_top -  (u_long) obj.vert_top);
		prim_size = ((u_long)obj.vert_top - (u_long)obj.primitive_top);

		if(g_normals)
		{
			LOG("\nHas g_normals\n");
			n_vertandnorm_size =  (u_long) total_size - ( (u_long) obj.vert_top + (u_long)sizeof(TMDHEADER));
			// norm_size =  total_size - (u_long) obj.normal_top;
			norm_size =  (u_long) obj.n_normal * sizeof(SVECTOR);
			//	norm_size+12;
		}
		else //vert only data
		{
			obj.n_normal =(u_long) 0;
			n_vertandnorm_size =  (u_long) vert_size + 0;
			norm_size =(u_long) 0; // Not sure why 32bytes need to be here
			// removing unused normals requires primitive top to be moved up
			//obj.primitive_top = obj.normal_top;
		}

		/*
		if(g_normals)
						fseek(rp,  (u_long)obj.vert_top, SEEK_SET);
					else
						fseek(rp,  vert_start, SEEK_SET);


					ret = fread(save_data,  1 , n_vertandnorm_size, rp);
		 */
		LOG("\n\n header correct ordered with info\n");

		LOG("\nheader id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("\n");
		LOG("3 longs = %d bytes - numbers below start after here and dont include the header!\n\n",sizeof(TMDHEADER) );

		LOG("primative block start location from hdr: %d includes object table(%d) but from zero = %d \n",(u_long)obj.primitive_top, sizeof(TMDOBJECT), (u_long)obj.primitive_top+sizeof(TMDHEADER) );
		LOG("each primative block is %d bytes: primative size=  %d  ending primitive location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ( prim_size/(u_long)obj.n_primitive), prim_size, prim_size+sizeof(TMDOBJECT),   prim_size+ sizeof(TMDOBJECT) + sizeof(TMDHEADER));

		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("\n");
		LOG("vert block start location hdr : %d includes  object table(%d) but from zero = %d \n",(u_long)obj.vert_top, sizeof(TMDOBJECT), (u_long)obj.vert_top+sizeof(TMDHEADER) );
		LOG("each vert_top block is %d bytes: vert size=  %d  ending vert location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ((u_long)prim_size/obj.n_primitive), prim_size, prim_size+sizeof(TMDOBJECT),  prim_size+ sizeof(TMDOBJECT) + sizeof(TMDHEADER));

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("\n");
		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);



		LOG(" n_vertandnorm_size %d \n", n_vertandnorm_size);
		LOG(" n_vert_top  %d  \n", (u_long) obj.vert_top);
		LOG(" g_tweens %d  \n", g_tweens);

		LOG(" total_size %d \n ", total_size);




		LOG(" vert_start %d  \n", vert_start);
		LOG(" (u_long)obj2.vert_top+12 %d  \n", ((u_long)(obj.vert_top)+12) );
		LOG(" vert_size %d  \n", vert_size);
		LOG(" norm_size %d  \n",  norm_size);

		LOG(" g_normals %d  \n",  g_normals);



		unlink("TMD_ANIM.PCK");

		wp = fopen( "TMD_ANIM.PCK", "wb+" );


		if(!wp)
		{

			fail("\n Error failed to open", "TMD_ANIM.PCK");
		}

		LOG("\n write # 0 vert_top 0x%0x %d  normal_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top,   (u_long)obj.normal_top, (u_long)obj.normal_top );

		LOG(" sizeof(u_long) %d \n\n", sizeof(u_long));

		// count starts from zero
		//g_tmd_count--;

		LOG(" g_tweens %d  \n", g_tweens);

		if(g_tweens ==  0)
		{
			// fwrite(&g_tmd_count, sizeof(u_long), 1, wp );
			HDR.frames = g_tmd_count;
		}
		else
		{
			u_long total;

			g_total_frames_calc = (g_tweens*g_tmd_count);


			if(!g_include_loopback)
				g_total_frames_calc -= g_tweens;


			LOG(" g_total_frames_calc new frames (frames + tweens) %d  \n",g_total_frames_calc );
			//fwrite(&total, sizeof(u_long), 1, wp );
			HDR.frames = g_total_frames_calc;
		}

		//fwrite(&vert_start, sizeof(u_long), 1, wp );


		//	fwrite(&n_vertandnorm_size, sizeof(u_long), 1, wp );
		//fwrite(&vert_size, sizeof(u_long), 1, wp );
		//fwrite(&norm_size, sizeof(u_long), 1, wp );

		//TMD pointer
		//fwrite(&vert_start, sizeof(u_long), 1, wp );

		// restore start from 1
		//g_tmd_count++;

		HDR.total_size =n_vertandnorm_size;
		HDR.vert_size =vert_size;
		HDR.norm_size =norm_size;

		fwrite(&HDR, sizeof(TMDANIMLISTHDR), 1, wp );

		LOG(" ftell write after header %d  \n",  ftell(wp));




		// write vert & norm of remaining TMDs
		save_data1 = malloc(n_vertandnorm_size);

		fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);




		ret  = fread( save_data1, 1,n_vertandnorm_size, rp);
		fclose(rp);

		if(ret != n_vertandnorm_size)
		{
			LOG("\n Error failed to read 1st %s TMD doesn't have the same amount of verts/normals as the first TMD %s\n", g_tmd_list[0], g_tmd_list[0]);
			LOG("\n");
			perror("TMD error");
			fflush(stdout);
			exit(1);
		}

		if(g_tweens)
		{
			save_data2	= malloc(n_vertandnorm_size);
			tween_data	= malloc(n_vertandnorm_size);
			firstframe_data = malloc(n_vertandnorm_size);
			memcpy(tween_data, save_data1, n_vertandnorm_size);
			memcpy(firstframe_data, save_data1, n_vertandnorm_size);
			LOG(" tween buffer created %d\n",ret );

			// ret  = fread( save_data2, 1,n_vertandnorm_size, rp);
			// fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);

		}

		if(g_tweens ==  0)
		{
			curr_frame = save_data1;
			curr_tween_to = NULL;
		}
		else
		{
			curr_frame = save_data2;
			curr_tween_to = save_data1;
		}

		// if no tweens, write first keyframe BEFORE looping
		if(!g_tweens)
		{
			// write TMD data (the first keyframe)
			ret = fwrite(save_data1 ,  1 , n_vertandnorm_size, wp);
			g_fileframes++;


			LOG("save first frame write:%d size:%d \n", ret, n_vertandnorm_size);
			if(ret != n_vertandnorm_size)
			{
				LOG("\n Error failed to write %d TMD %s\n",i, g_tmd_list[0]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}
		}



		LOG("\nwriting %d .tmds ...\n", g_tmd_count);

		// skip 1st main TMD file
		for (i = 1; i < g_tmd_count; i++)
		{
			LOG("\n processing file %d = <%s>\n", i, g_tmd_list[i]);
			LOG(" wp ftell %d 0x%0x  \n",  ftell(wp),  ftell(wp));


			rp = fopen( g_tmd_list[i], "rb" );

			if(rp == NULL)
			{
				LOG("\n Error failed to open %s\n", g_tmd_list[i]);
				LOG("\n");
				perror("File opening failed");
				fflush(stdout);
				exit(1);
			}


			rewind(rp);
			fread( &obj2, 1, sizeof(TMDHEADER), rp); //move FP
			ret = fread( &obj2, 1, sizeof(TMDOBJECT), rp);

			if(ret != sizeof(TMDOBJECT)  || obj.n_vert != obj2.n_vert ) // || obj.n_normal != obj2.n_normal || obj.n_primitive != obj2.n_primitive)
			{
				LOG("\n Error failed to read 1st %s TMD doesn't have the same amount of verts/normals as the first TMD %s\n", g_tmd_list[i], g_tmd_list[0]);
				LOG("\n");
				perror("TMD error");
				fflush(stdout);
				exit(1);
			}


			rewind(rp);

			/*
			if(g_normals)
				fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);
			else
				fseek(rp,  vert_start, SEEK_SET);
			 */
			fseek(rp,  ((u_long)(obj2.vert_top)+12), SEEK_SET);

			LOG(" rp ftell %d 0x%0x  \n",  ftell(rp),  ftell(rp));


			// read all vert & maybe the normal data
			ret = fread(curr_frame,  1 , n_vertandnorm_size, rp);
			fflush(rp);
			fclose(rp);
			LOG("save_data read:%d size:%d \n", ret, n_vertandnorm_size);

			if(ret != n_vertandnorm_size)
			{
				LOG("\n Error failed to read %d TMD %s\n",i, g_tmd_list[i]);
				LOG("\n");
				perror("File reading failed");
				fflush(stdout);
				exit(1);
			}



			svect_p = curr_frame;
			LOG(" svect XYZ %d  %d %d \n", svect_p->vx , svect_p->vy , svect_p->vz);

			LOG(" \n ----------- CVS data -----------\n count, X,Y,Z \n");


			if(g_verbose)
			{
				char line[512];
				int k;
				FILE *test;
				char name[255];
				sprintf(name, "vert%d.cvs",i );
				unlink(name);
				LOG(name);

				test = fopen( name, "w" );

				for(k=0; k<obj.n_vert; k++)
				{

					// LOG("%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
					sprintf(line, "%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
					//ret = fwrite(line ,  1 , sizeof(line), test);
					fprintf(test, "%s", line);
					svect_p++;
				}

				fprintf(test,"NORMAL, END, END, END, \n");

				if(g_normals)
					for(k=0; k<obj.n_normal; k++)
					{

						// LOG("%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
						sprintf(line, "%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
						//ret = fwrite(line ,  1 , sizeof(line), test);
						fprintf(test, "%s", line);
						svect_p++;
					}


				fprintf(test,"NORMAL, END, END, END, \n");

				LOG("\n");





				fclose(test);


				if(1)
				{
					FILE *test;
					char name[255];
					sprintf(name, "t%d.bin",i );
					unlink(name);
					LOG(name);
					LOG("\n");
					test = fopen( name, "wb+" );
					ret = fwrite(curr_frame ,  1 , n_vertandnorm_size, test);

					fclose(test);

				}
			}
			LOG(" \n ----------- CVS data END -----------\n \n");





			if(g_tweens > 0)
			{
				int t,k, verts;
				SVECTOR *vect_frame1, *vect_frame2, *vect_tween;


				LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);

				verts = (obj.n_vert+(obj.n_normal*g_normals));

				//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
				for(t=0; t<g_tweens; t++)
				{
					float mul;
					mul = ( 1.0f/g_tweens ); //fraction of the tween
					mul = mul* (float)t; // amount of the tween fraction for the current frame

					if(g_tweens < 3)
					{
						mul += 0.113f; // makes it look better
					}

					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					vect_frame1 =curr_frame;
					vect_frame2 = curr_tween_to;
					vect_tween = tween_data;

					LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
					LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

					for(k=0; k<verts; k++)
					{


						vect_tween->vx =  vect_frame2->vx+   (short) (  (float) ( (vect_frame1->vx)  -  (vect_frame2->vx)  )* (float)mul );
						vect_tween->vy =  vect_frame2->vy+   (short) (  (short) ( (vect_frame1->vy)  -  (vect_frame2->vy)  )* (float)mul );
						vect_tween->vz =   vect_frame2->vz+  (short) (  (short)( (vect_frame1->vz)  -  (vect_frame2->vz)  )* (float)mul );

						if(k==0)
						{
							LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
						}

						vect_frame1++;
						vect_frame2++;
						vect_tween++;
					}

					//write actual TMD data as last frame
					ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
					g_fileframes++;

					if(ret != n_vertandnorm_size)
					{
						LOG("\n Error failed to write tween %d from TMD %s\n",t, g_tmd_list[i]);
						LOG("\n");
						perror("File reading failed");
						fflush(stdout);
						exit(1);
					}
				}


				//flip buffers
				if(curr_frame == save_data2)
				{
					curr_frame = save_data1;
					curr_tween_to = save_data2;
				}
				else
				{
					curr_frame = save_data2;
					curr_tween_to = save_data1;
				}
			}
			else // no tweening only write tmd data
			{
				// write it out TMD data (the keyframe) first
				ret = fwrite(curr_frame ,  1 , n_vertandnorm_size, wp);
				g_fileframes++;

				LOG("save_data write:%d size:%d \n", ret, n_vertandnorm_size);
				if(ret != n_vertandnorm_size)
				{
					LOG("\n Error failed to write %d TMD %s\n",i, g_tmd_list[i]);
					LOG("\n");
					perror("File reading failed");
					fflush(stdout);
					exit(1);
				}
			}




		}

		// needs to tween the last frame!
		if(0)
		{

			int t,k, verts;
			SVECTOR *vect_frame1, *vect_frame2, *vect_tween;


			LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);


			verts =  (obj.n_vert+(obj.n_normal*g_normals));

			//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
			for(t=0; t<g_tweens; t++)
			{
				float mul;
				mul = ( 1.0f/g_tweens ); //fraction of the tween
				mul = mul* (float)t; // amount of the tween fraction for the current frame

				if(g_tweens < 3)
				{
					mul += 0.113f; // makes it look better
				}
				LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
				vect_frame1 =curr_frame;
				vect_frame2 = curr_tween_to;
				vect_tween = tween_data;

				LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
				LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

				for(k=0; k<verts; k++)
				{


					vect_tween->vx =  vect_frame2->vx+   (short) (  (float) ( (vect_frame1->vx)  -  (vect_frame2->vx)  )* (float)mul );
					vect_tween->vy =  vect_frame2->vy+   (short) (  (short) ( (vect_frame1->vy)  -  (vect_frame2->vy)  )* (float)mul );
					vect_tween->vz =   vect_frame2->vz+  (short) (  (short)( (vect_frame1->vz)  -  (vect_frame2->vz)  )* (float)mul );

					if(k==0)
					{
						LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
					}

					vect_frame1++;
					vect_frame2++;
					vect_tween++;
				}

				//write actual TMD data as last frame
				ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
				g_fileframes++;

				if(ret != n_vertandnorm_size)
				{
					LOG("\n Error failed to write tween %d from TMD %s\n",t, g_tmd_list[i]);
					LOG("\n");
					perror("File reading failed");
					fflush(stdout);
					exit(1);
				}
			}

#if 0
			//flip buffers
			if(curr_frame == save_data2)
			{
				curr_frame = save_data1;
				curr_tween_to = save_data2;
			}
			else
			{
				curr_frame = save_data2;
				curr_tween_to = save_data1;
			}
#endif


		}





		//   do last tweens

		if(g_include_loopback )
		{

			if(g_tweens)
			{
				int t,k, verts;
				SVECTOR *vect_frame1, *vect_frame2, *vect_tween;

				//flip back
				if(curr_frame == save_data2)
				{
					curr_frame = save_data1;
					curr_tween_to = save_data2;
				}
				else
				{
					curr_frame = save_data2;
					curr_tween_to = save_data1;
				}

				LOG(" \n ----------- LOOPBACK TWEEN -----------\n \n");
				LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);


				verts =  (obj.n_vert+(obj.n_normal*g_normals));


				//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
				for(t=0; t<g_tweens; t++)
				{
					float mul;
					mul = ( 1.0f/g_tweens );
					mul = mul* (float)t;

					if(g_tweens < 3)
					{
						mul += 0.113f; // makes it look better
					}

					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					vect_frame1 =curr_frame;
					vect_frame2 = curr_tween_to;
					vect_tween = tween_data;

					LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
					LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

					for(k=0; k<verts; k++)
					{
						vect_tween->vx =  vect_frame1->vx+   (short) (  (float) ( (vect_frame2->vx)  -  (vect_frame1->vx)  )* (float)mul );
						vect_tween->vy =  vect_frame1->vy+   (short) (  (short) ( (vect_frame2->vy)  -  (vect_frame1->vy)  )* (float)mul );
						vect_tween->vz =   vect_frame1->vz+  (short) (  (short)( (vect_frame2->vz)  -  (vect_frame1->vz)  )* (float)mul );

						if(k==0)
						{
							LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
						}

						vect_frame1++;
						vect_frame2++;
						vect_tween++;
					}

					//write actual TMD data as last frame
					ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
					g_fileframes++;

					if(ret != n_vertandnorm_size)
					{
						LOG("\n Error failed to write real frame  %d from TMD %s\n",t, g_tmd_list[i]);
						LOG("\n");
						perror("File reading failed");
						fflush(stdout);
						exit(1);
					}
				}

			}

		}


		/*
		obj.n_normal= 0;
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		 */


		printf("\n Frames stored: %d\n",g_fileframes);
		fclose(wp);

		free(save_data1);

		if(g_tweens)
		{
			free(save_data2);
			free(tween_data);
			free(firstframe_data);

		}

		for (i = 0; i < g_tmd_count; i++)
			free(g_tmd_list[i]);


	}
	else
	{
		printf("\n ERROR - no .TMD files found! \n");
	}


	return 0;

}
