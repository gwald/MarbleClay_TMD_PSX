#if 0

README FIRST!

To clean project CTRL - (CTRL and minus keys) then hit the A key for all, and F7 to make.

You can use any external editors and unticking MDI (in prefferences), ie: "C:\Program Files\Notepad++\notepad++.exe"  -n%line %file



CW debugger tips:

Hardware:
The CW debugger works great with the FTDI serial USB breakout boards (make sure its a geniun FTDI, spend the extra money from a creditable electronics supplier (not ebay or amazon!).
		Strongly recommend setting the FTDI coms port to 1, set all others to something else!

		Bits per second: 115200 (recommended)
		Data bits: 8
		Parity: None
		Stop bits: 1
		Flow control: Hardware

		CW Debugger:

		CW debugger has a pretty good RAM view and useful features, in a windows app.

		The debugger doesnt support mouse scroll wheel, if you plan on using CW a lot, install the mouse driver from C:\misc\mouse-drivers

				CW Debugger uses multi-window mode, a very old 1990's UI where there's no main window. It made it easy to customize the layout, over multiple monitors etc.
				Minizing to desktop and switching to the debugger, will help make it look like a single, fullscreen, window application.
				Dont let this scare you! Just use it a little for a while and configure it how you like, it will create a .gdb file with your settings (see prefferences).

				It has two main windows, the files view (all files and global vars) and the stack view (current file and stack vars), the stack view is where you actually debug.

				Before doing a run command in the debugger, get past GsInitGraph and ResetGraph, if not it will most likely crash.

				To clear the TTY text log output window, close it and it will reopen on the next printf.
				Recommend use breakpoints, stepping through a lot of code is slow!
				To copy the text from the log, use the mouse to select all the lines, dont let go of the mouse button and hit CTRL C to copy.

				Clicking next arrow sometimes doesnt update automatically, click the buttons and click inside the code or var panels etc
				Better to minimize that panel and use CTRL:
				S: Step (next)
				T: Through (step in)
				U: Ught (step out)
				R: Run



				Read or grep for help in C:\Program Files\Metrowerks\CodeWarrior

#endif



				// TMD struct info from:  morph demo and fileformat.pdf from NY@SCEE

#ifndef __TMDANIM__
#define __TMDANIM__

#define	PACK_VERSION 2
#define DEFAULT_ANIM_FRAME_SPEED 255

				// **** global structures that define the tmd file format

				typedef struct
				{
					u_long id;		// 0x00000041
					u_long flag;	// 1 if addresses real, 0 if offset
					u_long nobj;	// number of objects in TMD
				} TMD_HEADER;

#define setTMD_HEADER_DEFAULTS(t) \
		(t)->id = (0x00000041), (t)->flag = (1), (t)->nobj = (1)

#define setTMD_HEADER(t,_id,_flg,_num) \
		(t)->id = (_id), (t)->flag = (_flg), (t)->nobjs = (_num)


				typedef struct
				{
					u_long vert_top; // vertices table
					u_long n_vert; // number of vertices
					u_long normal_top; // normal table
					u_long n_normal; // number of normals
					u_long primitive_top;	// primatives table
					u_long n_primitive;// number of primatives
					long scale; // not used
				} TMD_OBJ_TABLE;


#define setTMD_OBJ_TABLE(t,_vt,_vn,_nt,_nn,_pt,_pn,_s) \
		(t)->vert_top = (_vt), (t)->n_vert = (_vn),	\
		(t)->normal_top = (_nt), (t)->n_normal = (_nn),	\
		(t)->primitive_top = (_pt), (t)->n_primitive = (_pn),	\
		(t)->scale = (_s)


				// primative table is made up of a collection of primatives headers, with there
				// primative data

				typedef struct
				{
					u_char olen, ilen, flag, mode;
				} PRIM_HDR;

#define setPRIM_HDR(p,_m,_f,_i,_o) \
		(p)->mode = (_m), (p)->flag = (_f), (p)->ilen = (_i), (p)->olen = (_o)


#define F_4_NL   0x29  // quad no texture no light
				typedef struct 			// ilen 3 olen 5
				{
					u_char r0, g0, b0, mode2;
					u_short vert0, vert1;
					u_short vert2, vert3;
				} TMD_F_4_NL;

#define setTMD_F_4_NL(t,_r,_g,_b,_vert0,_vert1,_vert2,_vert3) \
		(t)->mode2 = F_4_NL, \
		(t)->r0 = (_r), (t)->g0 = (_g), (t)->b0 = (_b), \
		(t)->vert0 = (_vert0), (t)->vert1 = (_vert1), \
		(t)->vert2 = (_vert2), (t)->vert3 = (_vert3)

				typedef struct
				{		/* short word type 3D vector */
					short	vx, vy;
					short	vz, pad;
				} TMD_SVECTOR;


				typedef struct
				{
					TMD_HEADER hdr;
					TMD_OBJ_TABLE obj;
				} TMD_HDR_OBJ;


				typedef struct
				{
					PRIM_HDR hdr;
					TMD_F_4_NL data;
				} TMD_PRIM_HDR_F4_NL;




				typedef struct
				{
					TMD_HEADER tmd_hdr;
					TMD_OBJ_TABLE obj_table;
					TMD_PRIM_HDR_F4_NL prim_data[6];
					TMD_SVECTOR vert_data[8];

				} TMD_FLAT_3D_RECT;


				typedef struct
				{
					TMD_HEADER tmd_hdr;
					TMD_OBJ_TABLE obj_table;
					TMD_PRIM_HDR_F4_NL prim_data[48]; // 4 faces x 8 points
					TMD_SVECTOR vert_data[8];

				} TMD_FLAT_3D_RECT_POINTS;






#define setTMD_FLAT_3D_RECT(t,_r,_g,_b,_norm,_vert0,_vert1,_vert2,_vert3) \
		(t)->mode2 = F_4, \
		(t)->r0 = (_r), (t)->g0 = (_g), (t)->b0 = (_b), \
		(t)->norm0 = (_norm), \
		(t)->vert0 = (_vert0), (t)->vert1 = (_vert1), \
		(t)->vert2 = (_vert2), (t)->vert3 = (_vert3)





				typedef struct {
					TMD_SVECTOR min, max;
				} TMD_MIN_MAX;


// version 2



				typedef struct {
					// TMD info 	u_long total_size; //size of vert+norm size
					u_long vert_size;
					u_long norm_size;
					u_long *vert_p;  // start verts
					u_long *normal_p; // start normal


#ifdef  GsDivMODE_NDIV // used in NY
					GsDOBJ2* obj2_p; // set to tmdanim.exe version
					struct TMDANIMHDR_T *next_anim_p; // next anim, or null for loop
#else
					u_long obj2_p;
					u_long next_anim_p; // next anim, or null for loop
#endif
					u_char frame_speed; // number of ticks before next frame
					u_char frames_cnt; // number of frames

				} TMDANIMHDR_T;

				typedef TMDANIMHDR_T TMDANIMHDR;

				// used in NY
#ifdef  GsDivMODE_NDIV




				typedef struct
				{
					TMD_HDR_OBJ *tmd;
					TMDANIMHDR *anim_tmd;
					TMDANIMHDR  *anim_next_p; // TMDANIMHDR pointer to next??
					//u_char anim_cnt;
					u_char frame_pos;

					u_char frame_time;
					SVECTOR rot;
					GsCOORDINATE2   player_coord_loc;

				} player_t;


				extern TMDANIMHDR g_TMD_lizard;

				extern player_t g_characters[4];




#if 0
				void *process_player(player_t *player,GsOT *othWorld);

				inline void process_no_normal_frame(TMDANIMHDR *anim)
				{
					printf("\n  process_no_normal_frame (anim->vert_p)  0x%x  0x%x \n", (anim->anim->vert_p),*(anim->anim->vert_p));
					*(anim->anim->vert_p) = (u_long) anim->anim + sizeof(TMDANIMHDR) +  (u_long)(anim->anim->total_size*anim->frame_pos);
				}

				/*
if(anim->norm_size)
				 *(anim->normal_p) = (u_long) anim + sizeof(TMDANIMHDR) +              (u_long)anim->vert_size +  (u_long) ( anim->total_size*frame);// list + sizeof(TMDANIMHDR);
				 */
				inline void process_with_normal_frame(TMDANIMHDR *anim)
				{
					printf("\n  process_with_normal_frame (list->vert_p)  0x%x  0x%x \n", (anim->anim->vert_p),*(anim->anim->vert_p));
					*(anim->anim->vert_p) = (u_long) anim->anim + sizeof(TMDANIMHDR) +  (u_long) ( anim->anim->total_size*anim->frame_pos);
					*(anim->anim->normal_p) = (u_long) anim->anim + sizeof(TMDANIMHDR)  +     (u_long)       anim->anim->vert_size +  (u_long) ( anim->anim->total_size*anim->frame_pos);

					// *(anim->anim->normal_p) = (u_long) ( ( (u_long) anim->anim + (u_long) sizeof(TMDANIMHDR)) + (u_long) (anim->anim->vert_size + (u_long)((u_long)anim->anim->total_size*(u_long)anim->frame_pos) ) );
					//	*(anim->normal_p) =       (u_long ) anim + sizeof(TMDANIMHDR) +     (u_long)       anim->vert_size + (u_long) (anim->total_size*frame);// list + sizeof(TMDANIMHDR);
				}

#endif



				// TOP_XYZ: Top corner of rectangle.
				// BOT_XYZ: Bottom corner of rectangle.
				// Note: XYZ values above are in local space and converted to world space via coord2 and GsSetLsMatrix, it can also be used without coord2 when rendering other objects.
				// RGB: set single colour for all faces, if RGB are all zero's it will auto colour each face.
				// obj2 is linked to TMD and coord2 is cleared and set to obj2.
				// Return: The TMD_FLAT_3D_RECT pointer returned should be free(); on exit.

				TMD_FLAT_3D_RECT *debug_create_rect(short top_X,  short top_Y, short top_Z,   short bot_X,  short bot_Y, short bot_Z, char r, char b, char g,     GsDOBJ2 *obj_rect, GsCOORDINATE2 * coord2_p);




#ifdef TMDANIM_IMPL
#define VAR_IMPL_TYPE
#else
#define VAR_IMPL_TYPE extern
#endif




				//#ifdef  GsDivMODE_NDIV
#endif

				//#ifndef __TMDANIM__
#endif
