//WARNING: Code is hacky and buggy, use at own risk, no warranty blah blah blah!
//TODO Big endian computer support?



//About:
// This tool is like MIMEWAVE.EXE (See the dino demo) but it doesn't use GTE (3D math accelerated hardware).
// It's more like kdf2 (http://www.netyaroze-europe.com/yaroze_scei/forum/program/archive/tool/kdf0201.lzh) but a smaller and poorer version.

#include "tmdanim_exe.h" // to build TCC and GCC versions
#include "tmdanim.h" //

//#define DEBUG
//#define DEBUG_CMD

#define TMDANIM_VERSION "v1 Aug 2023"

void print_help_exit(char *err_mesg)
{

	printf("TMDAnim version: %s \n\n", TMDANIM_VERSION);
	printf("TMDAnim help:\n");
	printf("TMDAnim packages a list of TMD vertices (and optionally normal data)\n in a TMD_ANIM.PCK file.\n");
	printf("It must be run in a folder where all the current frames (TMD files)\n are ordered from first to last. \n");

	if(!err_mesg)
	{
		printf("\nHit enter...\n");
		getchar();
	}

	printf("\n");
	printf("TMDAnim usage: \n");
	printf("Options are not case sensitive, example: \n tmdanim -T2 -L -MM -V  \n");
	printf("\n");
	printf("-T# Number of interpolated tweens (in between) frames. \n");
	printf("-L  Loops back, animation repeats.\n");
	printf("-NN No Normals - no normal data is stored (recommended). \n");
	printf("-MM Min Max - 2 3D points (SVECTOR) for each frame, in text & binary files. \n");
	printf("-V  Verbose, help, debugging mode.\n\n\n");
	printf("\nOutput is a TMD_ANIM.PCK file, optional MinMax .mm & .txt files\n");


	if(!err_mesg)
	{
		printf("\nHit enter...\n");
		getchar();
	}

	printf("\n");
	printf("Tips:\n");
	printf("Create a new folder for each animation pck.\n");
	printf("Put all TMD frames there, in alpha-num order.\n");
	printf("Rename output files and move to project, delete anim folder... repeat\n");
	printf("The animation files only contain verts (and sometimes normals - very big data!)\n");
	printf("Animation on the PSX requires a single original TMD file for all anim pcks.\n");
	printf("The single TMD is used to reference face and/or normal data.\n");


	if(!err_mesg)
	{
		printf("\nHit enter...\n");
		getchar();
	}
	printf("\n");
	printf("For more info see the verbose, code and the NY viewer.\n");
	printf("Or ask at http://netyaroze.com/chat \n");



	if(err_mesg)
		printf("\nERROR: \n%s\n", err_mesg);


	fflush(stdout);

	if(err_mesg)
		exit(1);
	else
		exit(0);

}

void error_exit(const char *msg, char *file)
{

	unlink("TMD_ANIM.PCK");

	if(msg)
		printf("Error: %s \n", msg);

	if(file)
		printf("File: %s \n", file);


	fflush(stdout);
	exit(1);
}


TMDANIMHDR  HDR;
int (*LOG)(const char *format, ...);



int DUMMY(const char *format, ...)
{
	return 0;
}



char *g_tmd_list[256] = { 0 };
u_long g_tweens =0;
u_long g_tmd_count = 0;
u_long g_normals =1;
u_long g_verbose = 0;

u_long g_frame_minmax = 0;
u_long g_fileframes = 0;
u_long g_include_loopback =0;
u_long g_total_frames_calc =0;





int write_min_max( TMD_SVECTOR * vect_frame1, u_long verts, u_long frame)
{
	FILE *test;
	TMD_MIN_MAX min_max = {0};
	char name[255];
	char buff[255];

	int ret, k;




	for(k=0; k<verts; k++)
	{
		if( vect_frame1->vx < min_max.min.vx)
			min_max.min.vx = vect_frame1->vx;

		if( vect_frame1->vx > min_max.max.vx)
			min_max.max.vx = vect_frame1->vx;


		if( vect_frame1->vy < min_max.min.vy)
			min_max.min.vy = vect_frame1->vy;

		if( vect_frame1->vy > min_max.max.vy)
			min_max.max.vy = vect_frame1->vy;

		if( vect_frame1->vz < min_max.min.vz)
			min_max.min.vz = vect_frame1->vz;

		if( vect_frame1->vz > min_max.max.vz)
			min_max.max.vz = vect_frame1->vz;


		vect_frame1++;
	}


	LOG("minmax binary files are DOS 8.3 format because dataman, the RAM/.h/siocons manager/generator!\n");
	LOG("load the f1.mm into RAM and you have a hit collision box or visual debugging box!\n");

	sprintf(name, "f%d.mm", frame);
	unlink(name);

	LOG("writing binary min max file %s \n", name);

	test = fopen( name, "wb+" );

	if(!test)
		error_exit(" failed to open min max file ", name);

	ret = fwrite( &min_max,  1 , sizeof(TMD_MIN_MAX), test);

	fclose(test);

	if(ret != sizeof(TMD_MIN_MAX))
	{

		LOG("\n Error failed to write write_min_max for frame %d  %s, wrote %d from %d size\n",frame, name, ret,  sizeof(TMD_MIN_MAX) );
		LOG("\n");
		error_exit(" min max ", name);
	}

	LOG("writing text min max file %s \n", name);

	sprintf(name, "frame%d_minmax.txt", frame);
	unlink(name);

	LOG("writing binary min max file %s \n", name);

	test = fopen( name, "w+" );

	if(!test)
		error_exit(" failed to open min max file ", name);

	sprintf(buff, "\n min_max data for frame %d  \n\n ", frame);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);


	sprintf(buff, "\n min.vx = %d  ", 	min_max.min.vx);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);

	sprintf(buff, "\n min.vy = %d  ", 	min_max.min.vy);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);

	sprintf(buff, "\n min.vz = %d\n  ", 	min_max.min.vz);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);






	// max

	sprintf(buff, "\n max.vx = %d  ", 	min_max.max.vx);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);

	sprintf(buff, "\n max.vy = %d  ", 	min_max.max.vy);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);

	sprintf(buff, "\n max.vz = %d\n  ", 	min_max.max.vz);
	LOG(buff);
	ret = fwrite( buff,  1 , strlen(buff), test);



	fclose(test);

}



int main(int argc, char *argv[]) {
	int index, curline, ret = 1;
	unsigned char temp;

#ifdef DEBUG
#ifdef DEBUG_CMD
	//tmdanim -L -t2 -MM
	char *debug_argv[]={
			"tmdanim",
			"-V",
			"-L",
			"-t3",
			"-MM"
	};
	argc = 5;
	argv =debug_argv;
#endif


#endif

#ifdef DEBUG
	LOG = printf;
#else
	LOG = DUMMY;
#endif //#ifdef DEBUG




	g_tmd_count = 0;


	// TODO: argv checks should be a loop
	if(argc > 1)
	{
		LOG("argc <%d>\n",argc );

		LOG("\n argv[1] <%s>\n",argv[1]);

		if (strcmp(argv[1], "-nn") == 0 || strcmp(argv[1], "-NN") == 0)
		{
			g_normals = 0;
			LOG("1 No normals set <%s>\n",argv[1]);
		}

		if (strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "-V") == 0)
			g_verbose = 1;

		if (strcmp(argv[1], "-mm") == 0 || strcmp(argv[1], "-MM") == 0)
			g_frame_minmax = 1;


		if (strstr(argv[1], "-l") > 0  || strstr(argv[1], "-L") > 0 )
		{

			g_include_loopback =1;
			LOG("\n 1 g_include_loopback -k <%d>\n",g_include_loopback);
		}


		if (strstr(argv[1], "-t") > 0  || strstr(argv[1], "-T") > 0 )
		{

			g_tweens = atoi(&argv[1][2]);
			LOG("\n 1 g_tweens -t <%d>\n",g_tweens);
		}


		if(argc > 2)
		{


			LOG("\n 2 argv[2] <%s>\n",argv[2]);

			if (strcmp(argv[2], "-v") == 0 || strcmp(argv[2], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[2], "-nn") == 0 || strcmp(argv[2], "-NN") == 0)
			{
				g_normals = 0;
				LOG("2 No normals set <%s>\n",argv[2]);
			}

			if (strcmp(argv[2], "-mm") == 0 || strcmp(argv[2], "-MM") == 0)
				g_frame_minmax = 1;

			if (strstr(argv[2], "-l") > 0  || strstr(argv[2], "-L") > 0 )
			{

				g_include_loopback =1;
				LOG("\n 2 g_include_loopback -k <%d>\n",g_include_loopback);
			}

			if (strstr(argv[2], "-t") > 0  || strstr(argv[2], "-T") > 0 )
			{

				g_tweens = atoi(&argv[2][2]);
				LOG("\n 2 g_tweens -t <%d>\n",g_tweens);
			}


		}


		if(argc > 3)
		{


			LOG("\n 3 argv[3] <%s>\n",argv[3]);

			if (strcmp(argv[3], "-v") == 0 || strcmp(argv[3], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[3], "-nn") == 0 || strcmp(argv[3], "-NN") == 0)
			{
				g_normals = 0;
				LOG("3 No normals set <%s>\n",argv[3]);
			}

			if (strcmp(argv[3], "-mm") == 0 || strcmp(argv[3], "-MM") == 0)
				g_frame_minmax = 1;

			if (strstr(argv[3], "-l") > 0  || strstr(argv[3], "-L") > 0 )
			{

				g_include_loopback =1;
				LOG("\n 3 g_include_loopback -k <%d>\n",g_include_loopback);
			}


			if (strstr(argv[3], "-t") > 0  || strstr(argv[3], "-T") > 0 )
			{

				g_tweens = atoi(&argv[3][2]);
				LOG("\n 3 g_tweens -t <%d>\n",g_tweens);
			}




		}




		if(argc > 4)
		{


			LOG("\n 4 argv[4] <%s>\n",argv[4]);

			if (strcmp(argv[4], "-v") == 0 || strcmp(argv[4], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[4], "-nn") == 0 || strcmp(argv[4], "-NN") == 0)
			{
				g_normals = 0;
				LOG("4 No normals set <%s>\n",argv[4]);
			}

			if (strcmp(argv[4], "-mm") == 0 || strcmp(argv[4], "-MM") == 0)
				g_frame_minmax = 1;

			if (strstr(argv[4], "-l") > 0  || strstr(argv[4], "-L") > 0 )
			{

				g_include_loopback =1;
				LOG("\n4 g_include_loopback -k <%d>\n",g_include_loopback);
			}


			if (strstr(argv[4], "-t") > 0  || strstr(argv[4], "-T") > 0 )
			{

				g_tweens = atoi(&argv[4][2]);
				LOG("\n4 g_tweens -t <%d>\n",g_tweens);
			}




		}





		if(argc > 5)
		{


			LOG("\n 5 argv[5] <%s>\n",argv[5]);

			if (strcmp(argv[5], "-v") == 0 || strcmp(argv[5], "-V") == 0)
				g_verbose = 1;

			if (strcmp(argv[5], "-nn") == 0 || strcmp(argv[5], "-NN") == 0)
			{
				g_normals = 0;
				LOG("5 No normals set <%s>\n",argv[5]);
			}

			if (strcmp(argv[5], "-mm") == 0 || strcmp(argv[5], "-MM") == 0)
				g_frame_minmax = 1;

			if (strstr(argv[5], "-l") > 0  || strstr(argv[5], "-L") > 0 )
			{

				g_include_loopback =1;
				LOG("\n5 g_include_loopback -k <%d>\n",g_include_loopback);
			}


			if (strstr(argv[5], "-t") > 0  || strstr(argv[5], "-T") > 0 )
			{

				g_tweens = atoi(&argv[5][2]);
				LOG("\n5 g_tweens -t <%d>\n",g_tweens);
			}




		}


	}
	else // no params
		print_help_exit(NULL);

	if(g_tweens == 1)
		g_tweens=0;



#ifdef DEBUG
	LOG = printf;
#else
	if(g_verbose)
		LOG = printf;
#endif //#ifdef DEBUG



	LOG("\n");

	{
		DIR *dir;
		struct dirent *ent;
		if ((dir = opendir(".")) != NULL)
		{
			/* print all the files and directories within directory */
			while ((ent = readdir(dir)) != NULL)
			{

				LOG("%d %s\n", g_tmd_count, ent->d_name);
				//if( !strcmp(ent->d_name, ".tmd") || !strcmp(ent->d_name, ".TMD")  )
				if( strstr(ent->d_name, ".tmd") || strstr(ent->d_name, ".TMD")  )
				{
					LOG("<%s>\n", ent->d_name);
					g_tmd_list[g_tmd_count] = calloc(1, strlen(ent->d_name)+1);
					memcpy(g_tmd_list[g_tmd_count], ent->d_name, strlen(ent->d_name));
					g_tmd_count++;
				}
			}
			closedir(dir);
		} else {
			/* could not open directory */
			error_exit("failed to open local directory",".");

		}
	}


	if(g_tmd_count > 0)
	{
		u_long ret, i, vert_start, prim_size, total_size, vert_top,n_vertandnorm_size, vert_size, norm_size ;
		char *save_data1;
		char *save_data2;
		char *tween_data;
		char *firstframe_data;

		char *curr_frame;
		char *curr_tween_to;

		FILE *rp, *wp;
		TMD_OBJ_TABLE obj, obj2;
		TMD_HEADER hdr;
		TMD_SVECTOR * svect_p;
		TMD_SVECTOR svect;

		i = 0;

		LOG("\nprocessing... g_tmd_count %d\n",g_tmd_count);

		LOG("\n%d = <%s>\n", i, g_tmd_list[i]);


		rp = fopen( g_tmd_list[i], "rb" );

		if(!rp)
		{

			error_exit("\n Error failed to open", g_tmd_list[i]);
		}

		fseek(rp, 0L, SEEK_END);
		total_size = ftell(rp);


		LOG(" 1st TMD total_size %d \n", total_size);

		//fseek(rp, 0L, SEEK_SET);
		rewind(rp);

		fread( &hdr, sizeof(TMD_HEADER), 1, rp);
		fread( &obj, sizeof(TMD_OBJ_TABLE), 1, rp);
		// fseek(rp, 0L, SEEK_SET);
		vert_top = sizeof(TMD_HEADER)+(u_long)obj.vert_top;



		LOG(" header as read from file!\n\n");

		LOG("header id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);


		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);





		/*

header as read from file!
header id 0x41 65
header flag 0x0 0
header noobj 0x1 1
object vert_top 0x4794 18324
object n_vert 0x388 904
object normal_top 0x63d4 25556
object n_normal 0x3ae 942
object primitive_top 0x1c 28
object n_primitive 0x3ae 942
object scale 0x0 0


actual file struct:
primitive_top 0x1c 28
(primative block start location from hdr: 28 includes only the object table(28) but from zero it's 40, OBJ & HDR (28+12=40) , same for the other top addr/sizes)
vert_top 0x4794 18324
normal_top 0x63d4 25556

		 */

		vert_start = (u_long)obj.vert_top + (u_long)sizeof(TMD_HEADER);
		vert_size =  ((u_long) obj.normal_top -  (u_long) obj.vert_top);
		prim_size = ((u_long)obj.vert_top - (u_long)obj.primitive_top);

		if(g_normals)
		{
			LOG("\nUsing normals obj.n_normal  %d \n", obj.n_normal );


			n_vertandnorm_size =  (u_long) total_size - ( (u_long) obj.vert_top + (u_long)sizeof(TMD_HEADER));
			// norm_size =  total_size - (u_long) obj.normal_top;
			norm_size =  (u_long) obj.n_normal * sizeof(TMD_SVECTOR);

			LOG("\n n_vertandnorm_size %d  norm_size %d \n", n_vertandnorm_size, norm_size );

			if( norm_size == 0)
			{
				fclose(rp);
				fclose(wp);
				error_exit("No normal data in TMD! re-export TMD with normals (Specular in MarbleCLay) or use tmdanim -NN ",  g_tmd_list[i] );
			}

			//	norm_size+12;
		}
		else //vert only data
		{
			obj.n_normal =(u_long) 0;
			n_vertandnorm_size =  (u_long) vert_size + 0;
			norm_size =(u_long) 0; // Not sure why 32bytes need to be here
			// removing unused normals requires primitive top to be moved up
			//obj.primitive_top = obj.normal_top;
		}

		/*
		if(g_normals)
						fseek(rp,  (u_long)obj.vert_top, SEEK_SET);
					else
						fseek(rp,  vert_start, SEEK_SET);


					ret = fread(save_data,  1 , n_vertandnorm_size, rp);
		 */
		LOG("\n\n header correct ordered with info\n");

		LOG("\nheader id 0x%0x %d\n", (u_long)hdr.id, (u_long)hdr.id);
		LOG("header flag 0x%0x %d\n", (u_long)hdr.flag, (u_long)hdr.flag);
		LOG("header noobj 0x%0x %d\n", (u_long)hdr.nobj, (u_long)hdr.nobj);

		LOG("\n");
		LOG("3 longs = %d bytes - numbers below start after here and dont include the header!\n\n",sizeof(TMD_HEADER) );

		LOG("primative block start location from hdr: %d includes object table(%d) but from zero = %d \n",(u_long)obj.primitive_top, sizeof(TMD_OBJ_TABLE), (u_long)obj.primitive_top+sizeof(TMD_HEADER) );
		LOG("each primative block is %d bytes: primative size=  %d  ending primitive location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ( prim_size/(u_long)obj.n_primitive), prim_size, prim_size+sizeof(TMD_OBJ_TABLE),   prim_size+ sizeof(TMD_OBJ_TABLE) + sizeof(TMD_HEADER));

		LOG("object primitive_top 0x%0x %d\n", (u_long)obj.primitive_top, (u_long)obj.primitive_top);
		LOG("object n_primitive 0x%0x %d\n", (u_long)obj.n_primitive,  (u_long)obj.n_primitive);

		LOG("\n");
		LOG("vert block start location hdr : %d includes  object table(%d) but from zero = %d \n",(u_long)obj.vert_top, sizeof(TMD_OBJ_TABLE), (u_long)obj.vert_top+sizeof(TMD_HEADER) );
		LOG("each vert_top block is %d bytes: vert size=  %d  ending vert location +from reading hdr = %d from zero = size+hdr+obj = %d\n",  ((u_long)prim_size/obj.n_primitive), prim_size, prim_size+sizeof(TMD_OBJ_TABLE),  prim_size+ sizeof(TMD_OBJ_TABLE) + sizeof(TMD_HEADER));

		LOG("object vert_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top);
		LOG("object n_vert 0x%0x %d\n", (u_long)obj.n_vert, (u_long)obj.n_vert);

		LOG("\n");
		LOG("object normal_top 0x%0x %d\n", (u_long)obj.normal_top, (u_long)obj.normal_top);
		LOG("object n_normal 0x%0x %d\n", (u_long)obj.n_normal, (u_long)obj.n_normal);

		LOG("object scale 0x%0x %d\n", (u_long)obj.scale, (u_long)obj.scale);



		LOG(" n_vertandnorm_size %d \n", n_vertandnorm_size);
		LOG(" n_vert_top  %d  \n", (u_long) obj.vert_top);
		LOG(" g_tweens %d  \n", g_tweens);

		LOG(" total_size %d \n ", total_size);




		LOG(" vert_start %d  \n", vert_start);
		LOG(" (u_long)obj2.vert_top+12 %d  \n", ((u_long)(obj.vert_top)+12) );
		LOG(" vert_size %d  \n", vert_size);
		LOG(" norm_size %d  \n",  norm_size);

		LOG(" g_normals %d  \n",  g_normals);



		unlink("TMD_ANIM.PCK");

		wp = fopen( "TMD_ANIM.PCK", "wb+" );


		if(!wp)
		{

			error_exit("\n Error failed to open", "TMD_ANIM.PCK");
		}

		LOG("\n write # 0 vert_top 0x%0x %d  normal_top 0x%0x %d\n", (u_long)obj.vert_top, (u_long)obj.vert_top,   (u_long)obj.normal_top, (u_long)obj.normal_top );

		LOG(" sizeof(u_long) %d \n\n", sizeof(u_long));

		// count starts from zero
		//g_tmd_count--;

		LOG(" g_tweens %d  \n", g_tweens);

		if(g_tweens ==  0)
		{
			// fwrite(&g_tmd_count, sizeof(u_long), 1, wp );
			HDR.frames_cnt = g_tmd_count;
		}
		else
		{
			u_long total;

			g_total_frames_calc = (g_tweens*g_tmd_count);


			if(!g_include_loopback)
				g_total_frames_calc -= g_tweens;


			LOG(" g_total_frames_calc new frames (frames + tweens) %d  \n",g_total_frames_calc );
			//fwrite(&total, sizeof(u_long), 1, wp );
			HDR.frames_cnt = g_total_frames_calc;
			HDR.loopback = g_include_loopback;
		}

		//fwrite(&vert_start, sizeof(u_long), 1, wp );


		//	fwrite(&n_vertandnorm_size, sizeof(u_long), 1, wp );
		//fwrite(&vert_size, sizeof(u_long), 1, wp );
		//fwrite(&norm_size, sizeof(u_long), 1, wp );

		//TMD pointer
		//fwrite(&vert_start, sizeof(u_long), 1, wp );

		// restore start from 1
		//g_tmd_count++;

		HDR.total_size =n_vertandnorm_size;
		HDR.vert_size =vert_size;
		HDR.norm_size =norm_size;

		fwrite(&HDR, sizeof(TMDANIMHDR), 1, wp );

		LOG(" ftell write after header %d  \n",  ftell(wp));




		// write vert & norm of remaining TMDs
		save_data1 = malloc(n_vertandnorm_size);

		fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);




		ret  = fread( save_data1, 1,n_vertandnorm_size, rp);
		fclose(rp);

		if(ret != n_vertandnorm_size)
		{
			error_exit(" Failed to read 1st %s TMD doesn't have the same amount of verts/normals as the first TMD.", g_tmd_list[i] );
		}

		if(g_tweens)
		{
			save_data2	= malloc(n_vertandnorm_size);
			tween_data	= malloc(n_vertandnorm_size);
			firstframe_data = malloc(n_vertandnorm_size);
			memcpy(tween_data, save_data1, n_vertandnorm_size);
			memcpy(firstframe_data, save_data1, n_vertandnorm_size);
			LOG(" tween buffer created %d\n",ret );

			// ret  = fread( save_data2, 1,n_vertandnorm_size, rp);
			// fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);

		}

		if(g_tweens ==  0)
		{
			curr_frame = save_data1;
			curr_tween_to = NULL;
		}
		else
		{
			curr_frame = save_data2;
			curr_tween_to = save_data1;
		}

		// if no tweens, write first keyframe BEFORE looping
		if(!g_tweens)
		{
			// write TMD data (the first keyframe)
			ret = fwrite(save_data1 ,  1 , n_vertandnorm_size, wp);
			g_fileframes++;


			LOG("save first frame write:%d size:%d \n", ret, n_vertandnorm_size);
			if(ret != n_vertandnorm_size)
			{
				LOG("\n Error failed to write %d TMD %s\n",i, g_tmd_list[0]);
				error_exit(" failed to write TMD.", g_tmd_list[i] );
			}
		}



		if(g_frame_minmax)
			write_min_max( (TMD_SVECTOR *) save_data1, obj.n_vert, i);


		LOG("\nwriting %d .tmds ...\n", g_tmd_count);

		// skip 1st main TMD file
		for (i = 1; i < g_tmd_count; i++)
		{
			LOG("\n processing file %d = <%s>\n", i, g_tmd_list[i]);
			LOG(" wp ftell %d 0x%0x  \n",  ftell(wp),  ftell(wp));


			rp = fopen( g_tmd_list[i], "rb" );

			if(rp == NULL)
			{
				error_exit(" failed to open file.", g_tmd_list[i] );
			}


			rewind(rp);
			fread( &obj2, 1, sizeof(TMD_HEADER), rp); //move FP
			ret = fread( &obj2, 1, sizeof(TMD_OBJ_TABLE), rp);

			if(ret != sizeof(TMD_OBJ_TABLE)  || obj.n_vert != obj2.n_vert ) // || obj.n_normal != obj2.n_normal || obj.n_primitive != obj2.n_primitive)
			{
				error_exit("TMD doesn't have the same amount of verts/normals as the first TMD!", g_tmd_list[i] );
			}


			rewind(rp);

			/*
			if(g_normals)
				fseek(rp,  ((u_long)(obj.vert_top)+12), SEEK_SET);
			else
				fseek(rp,  vert_start, SEEK_SET);
			 */
			fseek(rp,  ((u_long)(obj2.vert_top)+12), SEEK_SET);

			LOG(" rp ftell %d 0x%0x  \n",  ftell(rp),  ftell(rp));


			// read all vert & maybe the normal data
			ret = fread(curr_frame,  1 , n_vertandnorm_size, rp);
			fflush(rp);
			fclose(rp);
			LOG("save_data read:%d size:%d \n", ret, n_vertandnorm_size);

			if(ret != n_vertandnorm_size)
			{
				error_exit("  failed to read TMD", g_tmd_list[i] );
			}


			if(g_frame_minmax)
				write_min_max((TMD_SVECTOR *) curr_frame, obj.n_vert, i);


			svect_p = (TMD_SVECTOR *) curr_frame;
			LOG(" svect XYZ %d  %d %d \n", svect_p->vx , svect_p->vy , svect_p->vz);

			LOG(" \n ----------- CVS data -----------\n count, X,Y,Z \n");

#ifdef DEBUG
			if(1)
			{
				char line[512];
				int k;
				FILE *test;
				char name[255];
				sprintf(name, "vert%d.cvs",i );
				unlink(name);
				LOG(name);

				test = fopen( name, "w" );

				for(k=0; k<obj.n_vert; k++)
				{

					// LOG("%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
					sprintf(line, "%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
					//ret = fwrite(line ,  1 , sizeof(line), test);
					fprintf(test, "%s", line);
					svect_p++;
				}

				fprintf(test,"NORMAL, END, END, END, \n");

				if(g_normals)
					for(k=0; k<obj.n_normal; k++)
					{

						// LOG("%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
						sprintf(line, "%d, %d, %d, %d, \n", k, svect_p->vx , svect_p->vy , svect_p->vz);
						//ret = fwrite(line ,  1 , sizeof(line), test);
						fprintf(test, "%s", line);
						svect_p++;
					}


				fprintf(test,"NORMAL, END, END, END, \n");

				LOG("\n");





				fclose(test);


				if(1)
				{
					FILE *test;
					char name[255];
					sprintf(name, "t%d.bin",i );
					unlink(name);
					LOG(name);
					LOG("\n");
					test = fopen( name, "wb+" );
					ret = fwrite(curr_frame ,  1 , n_vertandnorm_size, test);

					fclose(test);

				}




			}//if .CVS and .bin files


#endif //#ifdef DEBUG


			LOG(" \n ----------- CVS data END -----------\n \n");





			if(g_tweens > 0)
			{
				int t,k, verts;
				TMD_SVECTOR *vect_frame1, *vect_frame2, *vect_tween;


				LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);

				verts = (obj.n_vert+(obj.n_normal*g_normals));

				//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
				for(t=0; t<g_tweens; t++)
				{
					float mul;
					mul = ( 1.0f/g_tweens ); //fraction of the tween
					mul = mul* (float)t; // amount of the tween fraction for the current frame

					if(g_tweens < 3)
					{
						mul += 0.113f; // makes it look better
					}

					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					vect_frame1 =(TMD_SVECTOR *) curr_frame;
					vect_frame2 =(TMD_SVECTOR *)  curr_tween_to;
					vect_tween =(TMD_SVECTOR *)  tween_data;

					LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
					LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

					for(k=0; k<verts; k++)
					{


						vect_tween->vx =  vect_frame2->vx+   (short) (  (float) ( (vect_frame1->vx)  -  (vect_frame2->vx)  )* (float)mul );
						vect_tween->vy =  vect_frame2->vy+   (short) (  (short) ( (vect_frame1->vy)  -  (vect_frame2->vy)  )* (float)mul );
						vect_tween->vz =   vect_frame2->vz+  (short) (  (short)( (vect_frame1->vz)  -  (vect_frame2->vz)  )* (float)mul );

						if(k==0)
						{
							LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
						}

						vect_frame1++;
						vect_frame2++;
						vect_tween++;
					}

					//write actual TMD data as last frame
					ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
					g_fileframes++;

					if(ret != n_vertandnorm_size)
					{

						error_exit(" failed to write tween data from TMD!", g_tmd_list[i] );
					}
				}


				//flip buffers
				if(curr_frame == save_data2)
				{
					curr_frame = save_data1;
					curr_tween_to = save_data2;
				}
				else
				{
					curr_frame = save_data2;
					curr_tween_to = save_data1;
				}
			}
			else // no tweening only write tmd data
			{
				// write it out TMD data (the keyframe) first
				ret = fwrite(curr_frame ,  1 , n_vertandnorm_size, wp);
				g_fileframes++;

				LOG("save_data write:%d size:%d \n", ret, n_vertandnorm_size);
				if(ret != n_vertandnorm_size)
				{
					error_exit(" failed to write frame data from TMD!", g_tmd_list[i] );
				}
			}




		}

		// needs to tween the last frame!
		if(0)
		{

			int t,k, verts;
			TMD_SVECTOR *vect_frame1, *vect_frame2, *vect_tween;


			LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);


			verts =  (obj.n_vert+(obj.n_normal*g_normals));

			//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
			for(t=0; t<g_tweens; t++)
			{
				float mul;
				mul = ( 1.0f/g_tweens ); //fraction of the tween
				mul = mul* (float)t; // amount of the tween fraction for the current frame

				if(g_tweens < 3)
				{
					mul += 0.113f; // makes it look better
				}
				LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
				vect_frame1 =(TMD_SVECTOR *) curr_frame;
				vect_frame2 =(TMD_SVECTOR *)  curr_tween_to;
				vect_tween =(TMD_SVECTOR *)  tween_data;

				LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
				LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

				for(k=0; k<verts; k++)
				{


					vect_tween->vx =  vect_frame2->vx+   (short) (  (float) ( (vect_frame1->vx)  -  (vect_frame2->vx)  )* (float)mul );
					vect_tween->vy =  vect_frame2->vy+   (short) (  (short) ( (vect_frame1->vy)  -  (vect_frame2->vy)  )* (float)mul );
					vect_tween->vz =   vect_frame2->vz+  (short) (  (short)( (vect_frame1->vz)  -  (vect_frame2->vz)  )* (float)mul );

					if(k==0)
					{
						LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
					}

					vect_frame1++;
					vect_frame2++;
					vect_tween++;
				}

				//write actual TMD data as last frame
				ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
				g_fileframes++;

				if(ret != n_vertandnorm_size)
				{
					error_exit(" failed to write tween data from TMD!", g_tmd_list[i] );
				}
			}

#if 0
			//flip buffers
			if(curr_frame == save_data2)
			{
				curr_frame = save_data1;
				curr_tween_to = save_data2;
			}
			else
			{
				curr_frame = save_data2;
				curr_tween_to = save_data1;
			}
#endif


		}





		//   do last tweens

		if(g_include_loopback )
		{

			if(g_tweens)
			{
				int t,k, verts;
				TMD_SVECTOR *vect_frame1, *vect_frame2, *vect_tween;

				//flip back
				if(curr_frame == save_data2)
				{
					curr_frame = save_data1;
					curr_tween_to = save_data2;
				}
				else
				{
					curr_frame = save_data2;
					curr_tween_to = save_data1;
				}

				LOG(" \n ----------- LOOPBACK TWEEN -----------\n \n");
				LOG(" \n ----------- TWEENS for TMD %s loop:%d %d/%d  -----------\n \n",  g_tmd_list[i] ,i, g_fileframes,g_total_frames_calc);


				verts =  (obj.n_vert+(obj.n_normal*g_normals));


				//#define mul ( ( (2.5+g_tweens) / (t+2.0)  ) )
				for(t=0; t<g_tweens; t++)
				{
					float mul;
					mul = ( 1.0f/g_tweens );
					mul = mul* (float)t;

					if(g_tweens < 3)
					{
						mul += 0.113f; // makes it look better
					}

					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					LOG("  tween #%d   verts %d / %f \n", t, verts, mul );
					vect_frame1 =(TMD_SVECTOR *)  curr_frame;
					vect_frame2 =(TMD_SVECTOR *)  curr_tween_to;
					vect_tween =(TMD_SVECTOR *)  tween_data;

					LOG(" 1 vect_frame1 XYZ %d  %d %d \n", vect_frame1->vx , vect_frame1->vy , vect_frame1->vz);
					LOG(" 2 vect_frame2 XYZ %d  %d %d \n", vect_frame2->vx , vect_frame2->vy , vect_frame2->vz);

					for(k=0; k<verts; k++)
					{
						vect_tween->vx =  vect_frame1->vx+   (short) (  (float) ( (vect_frame2->vx)  -  (vect_frame1->vx)  )* (float)mul );
						vect_tween->vy =  vect_frame1->vy+   (short) (  (short) ( (vect_frame2->vy)  -  (vect_frame1->vy)  )* (float)mul );
						vect_tween->vz =   vect_frame1->vz+  (short) (  (short)( (vect_frame2->vz)  -  (vect_frame1->vz)  )* (float)mul );

						if(k==0)
						{
							LOG(" first vect_tween updated XYZ  %d  %d %d  \n", vect_tween->vx , vect_tween->vy , vect_tween->vz);
						}

						vect_frame1++;
						vect_frame2++;
						vect_tween++;
					}

					//write actual TMD data as last frame
					ret = fwrite(tween_data ,  1 , n_vertandnorm_size, wp);
					g_fileframes++;

					if(ret != n_vertandnorm_size)
					{

						error_exit(" failed to write real frame data from TMD!", g_tmd_list[i] );
					}
				}

			}

		}


		/*
		obj.n_normal= 0;
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		fwrite(&obj.n_normal, sizeof(u_long), 1, wp );
		 */


		printf("\n Frames stored: %d\n",g_fileframes);
		fclose(wp);

		free(save_data1);

		if(g_tweens)
		{
			free(save_data2);
			free(tween_data);
			free(firstframe_data);

		}

		for (i = 0; i < g_tmd_count; i++)
			free(g_tmd_list[i]);


	}
	else
	{

		print_help_exit("No TMD files found!");

	}





	return 0;

}
